# TBOT (Self Balancing Robot)

The self balancing robot firmware is developed with NXPs MCUXpresso, and runs on the Cortex M7 of the Verdin iMX8M Plus Quad 4GB.

The firmware requires Device Tree modifications, which can be found in TBOT's documentation in confluence. The DT modifications disable ethernet as it shares the same IO banks as some GPIOs.

This repository is part of the **Toradex T-Bot project**. To check all software components, such as OS customization, the Robot's UI, and the Python telemetry and control application, see [T-Bot OS Cutomization](https://gitlab.int.toradex.com/ma/demos/t-bot/operating-system/tbot-os-customization).

## Structure

The firmware is divided across 4 directories, plus the main file (`robot_fw.c`).

### src directory

The files in this directory use the drivers and libs to describe, configure, and manipulate the robot's hardware.

This directory contains the main file, `main.c`, which contains the main loop, initialization functions, and control algorithm.

### libs directory

The files in this directory are not related to this specific project, and can be used in other places. The libs implement the system timer, shared memory, error handling, and logging.

### drivers directory

This directory contains files related to this project, implementing the motor drivers, encoder, and accelerometer/gyro.

### armgcc dir

This directory contains configuration files (`CMakeLists.txt`, `config.cmake`, and `flags.cmake`), linker scripts, cleanup scripts, and temporaries created by cmake.

### nxp_files

Configuration source files (in C) required by MCUXpresso are stored here, for example, every pin used in this project is configured in `pin_mux.c` (in `BOARD_InitPins()`).

## How to build

1. Clone this repository
2. Get the mcuxpresso container: `./pull_container.sh`
3. Run the build scripts: `./build.sh release` or `./build.sh debug`
4. Scp the files to the module

## Module configuration

The firmware requires a torizon image with many device tree peripherals disabled. This image is available in TBOT's confluence page.

The boot command should be [updated in uboot](https://developer.toradex.com/software/cortex-m/how-to-load-binaries/#v-imx8mp) to start the Cortex M7 with the binary generaged in [How to build](#how-to-build) section.

The robot should automatically balance after u-boot counter reaches 0.
