#ifndef ROBOT_ENCODERS_H
#define ROBOT_ENCODERS_H

#include <inttypes.h>

extern uint8_t encoder_1;
extern uint8_t encoder_2;

#endif // ROBOT_ENCODERS_H
