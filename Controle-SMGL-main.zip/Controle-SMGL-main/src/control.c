#include "control.h"
#include "robot_encoders.h"

#include <math.h>

motor_data_t motor_1_data = {0};
motor_data_t motor_2_data = {0};

float drv8874_feedback_v2(
    drv8874_config_t *config,
    motor_data_t     *mdata,
    const uint8_t encoder,
    const float   mps_target,
    const float   dt
) {
    const float kp  =  240.0f;
    const float ki  = 3600.0f;

    const float mps   = COUNTS_TO_METERS*tdxenc_get_cps(encoder);
    const float error = mps_target - mps;

    // Integral
    mdata->integ += ki*error*dt;

    if     (mdata->integ >  100.0f) mdata->integ =  100.0f;
    else if(mdata->integ < -100.0f) mdata->integ = -100.0f;

    // Proportional
    const float prop = kp*error;

    // Duty
    const float duty = prop + mdata->integ;

    // Apply value
    drv8874_set_duty(config, duty);

    return duty;
}

void feedback_v3(
    feedback_data_v3_t *fbdata,
    drv8874_config_t   *config_1,
    drv8874_config_t   *config_2,
    const float dist,
    const float speed,
    const float angle,
    const float ang_vel,
    const float turn_diff,
    const float dt,
    float *duty,
    float *rpm
) {
    // Head forward = negarive => -(cst)
    // l = angle*radius
    const float k_wheel_angle = -0.04f;

    // This fusion has a huge impact somehow
    const float dist_fusion   = dist + angle*k_wheel_angle;
    const float speed_fusion  = speed + ang_vel*k_wheel_angle;
    //const float dist_fusion   = dist;
    //const float speed_fusion  = speed;

    // This constant makes the "maximum effort" angle 75deg instead of 90deg. We divide by the constant afterwards to keep the
    const float ang_conv = 90.0f/75.0f;
    // approx tan(x) ≃ x for a small angle x.
    // Please note that 60deg is our kill switch angle, so if the control reaches 60deg we are already dead.
    const float ang_error = tanf(ang_conv*(0.0f - angle))/ang_conv;

    fbdata->ang_error_integ  += ang_error*dt;

    const float pos_error     = 0.0f - dist_fusion;
    fbdata->pos_error_integ  += pos_error*dt;

    // Find the desired resulting speed in m/s
    float control_mps =
        fbdata->k_pos_integ * fbdata->pos_error_integ +
        fbdata->k_pos       * (0.0f - dist_fusion)    +
        fbdata->k_spd       * (0.0f - speed_fusion)   +
        fbdata->k_ang_integ * fbdata->ang_error_integ +
        fbdata->k_ang       * ang_error               +
        fbdata->k_ang_vel   * (0.0f - ang_vel);

    // The speed the encoder should aim is not the "real" robot speed,
    // so we must go back to its reference frame
    control_mps -= ang_vel*k_wheel_angle;

    *rpm = control_mps;

    *duty = drv8874_feedback_v2(config_1, &motor_1_data, encoder_1, control_mps + turn_diff, dt);
    drv8874_feedback_v2(config_2, &motor_2_data, encoder_2, control_mps - turn_diff, dt);
}
