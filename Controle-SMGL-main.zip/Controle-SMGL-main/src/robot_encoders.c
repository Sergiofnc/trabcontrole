
#include "robot_encoders.h"
#include "drivers/encoder_int.h"

uint8_t encoder_1 = 0;
uint8_t encoder_2 = 0;

// Setting up the encoder interrupt GPIO IRQ Handlers here.
// These functions are weakly defined in MCUXpresso,
// and we are just overriding the symbol here.
// Do not rename the functions below.

void GPIO4_Combined_0_15_IRQHandler() {
    tdxenc_irq_handler();
    SDK_ISR_EXIT_BARRIER;
}

void GPIO4_Combined_16_31_IRQHandler() {
    tdxenc_irq_handler();
    SDK_ISR_EXIT_BARRIER;
}
