#ifndef CONTROL_H
#define CONTROL_H

#include "fsl_pwm.h"
#include "fsl_i2c.h"

#include "nxp_files/pin_mux.h"
#include "nxp_files/clock_config.h"
#include "nxp_files/board.h"

#include "fsl_common.h"

#include "drivers/drv8874.h"
#include "drivers/lsm6dso.h"
#include "drivers/encoder_int.h"

#include "libs/tdxlog.h"
#include "libs/tdxerr.h"
#include "libs/tdxshm.h"
#include "libs/tdxtick.h"

#include "control.h"
#include "motor_defs.h"

typedef struct {
    float integ;
    float deriv;
    float v1;
    float v2;
    float v3;
} motor_data_t;

typedef struct {
    float k_cg;
    float k_ang_integ;
    float k_ang;
    float k_ang_vel;
    float k_pos;
    float k_spd;
    float k_damp;
    float ang_error_integ;
} feedback_data_t;

typedef struct {
    float k_ang_integ;
    float k_ang;
    float k_ang_vel;
    float k_pos_integ;
    float k_pos;
    float k_spd;
    float ang_error_integ;
    float pos_error_integ;
} feedback_data_v3_t;

[[ maybe_unused ]]
void feedback_v3(
    feedback_data_v3_t *fbdata,
    drv8874_config_t   *config_1,
    drv8874_config_t   *config_2,
    const float        dist,
    const float        speed,
    const float        angle,
    const float        ang_vel,
    const float        turn_diff,
    const float        dt,
    float              *duty,
    float              *rpm
);

#endif // CONTROL_H
