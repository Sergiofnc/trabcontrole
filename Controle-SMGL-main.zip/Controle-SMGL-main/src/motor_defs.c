#include "motor_defs.h"

#include <stdbool.h>

// Left Motor
drv8874_config_t drv8874_1_config = {
    .ph_base     = GPIO4,
    .ph_pin      = 0U,
    .nsleep_base = GPIO4,
    .nsleep_pin  = 26U,
    .pwm_base    = PWM1,
    .reverse     = true,
};

// Right Motor
drv8874_config_t drv8874_2_config = {
    .ph_base     = GPIO4,
    .ph_pin      = 29U,
    .nsleep_base = GPIO4,
    .nsleep_pin  = 27U,
    .pwm_base    = PWM2,
    .reverse     = false,
};
