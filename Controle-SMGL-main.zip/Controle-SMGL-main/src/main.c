#include "fsl_device_registers.h"

#include <inttypes.h>

// Using just to get PI
#define __USE_MISC
#include <math.h>

#include "fsl_pwm.h"
#include "fsl_i2c.h"

#include "nxp_files/pin_mux.h"
#include "nxp_files/clock_config.h"
#include "nxp_files/board.h"

#include "fsl_common.h"

#include "drivers/drv8874.h"
#include "drivers/lsm6dso.h"
#include "drivers/encoder_int.h"

#include "libs/kalman.h"
#include "libs/tdxlog.h"
#include "libs/tdxerr.h"
#include "libs/tdxshm.h"
#include "libs/tdxtick.h"

#include "control.h"
#include "motor_defs.h"
#include "robot_encoders.h"

#define DEG_TO_RAD (((float)M_PI)/180.f)
#define RAD_TO_DEG (180.f/(float)M_PI)

lsm6dso_t lsm6dso;

void init_periphs() {
    // ===== init time counting =====
    LOG_DEBUG("system core clock is %u", SystemCoreClock);

    LOG_DEBUG("init time");
    txdtick_init();

    // ===== init comms =====
    LOG_DEBUG("init comms");

    // ===== init motor drv =====
    LOG_DEBUG("init motor driver #1");
    drv8874_init(&drv8874_1_config, 40000);

    LOG_DEBUG("init motor driver #2");
    drv8874_init(&drv8874_2_config, 40000);

    // ===== init accel =====
    LOG_DEBUG("init accelerometer");

    // Set I2C source to SysPLL1 Div5 160MHZ
    CLOCK_SetRootMux(kCLOCK_RootI2c4, kCLOCK_I2cRootmuxSysPll1Div5);
    // Set root clock to 160MHZ / 10 = 16MHZ
    CLOCK_SetRootDivider(kCLOCK_RootI2c4, 1U, 10U);
    // SYSTEM PLL1 DIV5
    const uint32_t source_clock = CLOCK_GetPllFreq(kCLOCK_SystemPll1Ctrl)/CLOCK_GetRootPreDivider(kCLOCK_RootI2c4)/CLOCK_GetRootPostDivider(kCLOCK_RootI2c4)/5;

    i2c_master_config_t i2c_config;
    I2C_MasterGetDefaultConfig(&i2c_config);
    i2c_config.baudRate_Bps = 400000;

    I2C_MasterInit(I2C4, &i2c_config, source_clock);

    lsm6dso = lsm6dso_new(I2C4);

    // ===== init encoder =====
    LOG_DEBUG("init encoder #1");
    encoder_1 = tdxenc_new_enc(
        GPIO4, 23, GPIO4_Combined_16_31_IRQn,
        GPIO4, 24, GPIO4_Combined_16_31_IRQn,
        false, // not reversed
        tdxtick_sec_to_tick(500e-6f)
    );

    LOG_DEBUG("init encoder #2");
    encoder_2 = tdxenc_new_enc(
        GPIO4, 20, GPIO4_Combined_16_31_IRQn,
        GPIO4, 2, GPIO4_Combined_0_15_IRQn,
        false, // not reversed
        tdxtick_sec_to_tick(500e-6f)
    );
}

// In case of error, use to clear all peripheral configurations, reset states, ...
void deinit_all() {
    // Deallocate all enconders
    tdxenc_deinit();
}

// Main loop, stays here until end of time or some unrecoverable error.
void main_loop() {
    uint64_t now = tdxtick_get_tick();
    float dist_avg       = 0.0f;
    float speed_avg      = 0.0f;
    float ang_vel        = 0.0f;
    float ang_vel_smooth = 0.0f;
    float raw_angle      = 0.0f;
    float angle          = 0.0f;
    float motor_duty     = 0.0f;
    float motor_target_speed = 0.0f;

    feedback_data_v3_t feedback_data_v3 = {
        .k_ang_integ =     0.0f,
        .k_ang       =     0.65f,
        .k_ang_vel   =     0.10f, // 0.2f
        .k_pos_integ =    -0.01f,
        .k_pos       =    -0.30f,
        .k_spd       =    -1.25f,
        .ang_error_integ = 0.0f,
        .pos_error_integ = 0.0f,
    };

    // DRV8874
    // TODO: Maybe reduce even more
    uint64_t ctl_loop_dt   = tdxtick_sec_to_tick(40.05e-6f);
    uint64_t ctl_loop_last = now;
    uint64_t ctl_loop_next = now + ctl_loop_dt;

    // LSM6DSO
    // TODO: Maybe reduce even more
    uint64_t lsm6dso_dt   = tdxtick_sec_to_tick(40e-6f);
    uint64_t lsm6dso_last = now;
    uint64_t lsm6dso_next = now;
    lsm6dso_data_t imu_rx_buf  = {.x=0, .y=0, .z=0};
    lsm6dso_data_t gyro_data   = {.x=0, .y=0, .z=0};
    lsm6dso_data_t accel_data  = {.x=0, .y=0, .z=0};
    const float ang_vel_k_damp = 75.0f;

    // Using a low pass filter to cut drift in the gyro angle integration
    float lsm6dso_drift_compensation_value  = 0.0f;

    // This should be in 1/s, with 1 = 100%
    // lets aim at 5% per minute
    float lsm6dso_drift_compensation_factor = 0.05f/60.0f;

    // Kalman
    #ifdef ENABLE_KALMAN
    kalman_t imu_kalman;
    kalman_init(&imu_kalman, -42.5f*DEG_TO_RAD);
    float accel_angle    = 0.0f;
    float filtered_angle = 0.0f;
    #endif

    // SHM
    uint64_t shm_tx_dt   = tdxtick_sec_to_tick(500.0e-6f);
    uint64_t shm_tx_next = now + shm_tx_dt;

    uint64_t shm_rx_dt   = tdxtick_sec_to_tick(1.0f);
    uint64_t shm_rx_next = now + shm_rx_dt;

    volatile tdxshm_tx_payload_t *shm_tx_payload = (tdxshm_tx_payload_t*)SHARED_MEM_TX_ADDRESS;
    volatile tdxshm_rx_payload_t *shm_rx_payload = (tdxshm_rx_payload_t*)SHARED_MEM_RX_ADDRESS;
    shm_rx_payload->flag = 0.0f;
    shm_tx_payload->flag = 0.0f;
    shm_tx_payload->is_dead = 0;
    bool is_dead = false;

    // Time management
    uint64_t iter_begin     = 0;
    float iter_duration     = 0.0f;
    float iter_max_duration = 0.0f;
    float iter_avg_duration = 0.0f;
    float iter_avg_jitter   = 0.0f;
    float iter_avg_cst      = 20.0f;

    // We need a initial reference as this variable is updated at the end of the loop
    iter_begin = tdxtick_get_tick();

    while(true) {
        now = tdxtick_get_tick();

        // LSM6DSO
        if(now >= lsm6dso_next) {
            //const lsm6dso_accel_data_t accel = lsm6dso_read_accel();
            //const lsm6dso_gyro_data_t  gyro = lsm6dso_read_gyro();
            //LOG_INFO("accel.x = %+6.2fm/s2 .y = %+6.2fm/s2 .z = %+6.2fm/s2", accel.x, accel.y, accel.z);
            const lsm6dso_fsm_result_t fsm_result = lsm6dso_fsm(&lsm6dso, &imu_rx_buf);

            // FSM takes some time due to I2C, we should get a better reference:
            now = tdxtick_get_tick();

            // Handle new accel data
            if(fsm_result == LSM6DSO_NEW_ACCEL_DATA) {
                // imu_rx_buf contains accel data, lets use it to update the current gyro data
                accel_data = imu_rx_buf;
            }

            // Handle new gyro data
            if(fsm_result == LSM6DSO_NEW_GYRO_DATA) {
                // imu_rx_buf contains gyro data, lets use it to update the current gyro data
                gyro_data = imu_rx_buf;

                // then use the new gyro data to update other variables
                //LOG_INFO("gyro.x  = %+6.2fdps  .y = %+6.2fdps .z =  %+6.2fdps done in %7.2fus", gyro_data.x, gyro_data.y, gyro_data.z, 1.0e6f*tdxtick_time_diff_now(lsm6dso_next));
                ang_vel = gyro_data.x;
            }

            const float dt = tdxtick_time_diff(lsm6dso_last, now);
            ang_vel_smooth -= ang_vel_smooth*ang_vel_k_damp*dt;
            ang_vel_smooth += gyro_data.x*ang_vel_k_damp*dt;

            raw_angle += ang_vel*dt;

            // Drift compensation
            lsm6dso_drift_compensation_value -= lsm6dso_drift_compensation_value*lsm6dso_drift_compensation_factor*dt;
            lsm6dso_drift_compensation_value += raw_angle*lsm6dso_drift_compensation_factor*dt;

            angle = raw_angle - lsm6dso_drift_compensation_value;

            #ifdef ENABLE_KALMAN
            accel_angle    = get_accel_angle(accel_data.y, accel_data.z) + 41.5f*DEG_TO_RAD;
            filtered_angle = kalman_update(&imu_kalman, accel_angle, gyro_data.x, dt);
            #endif

            lsm6dso_last  = now;
            lsm6dso_next += lsm6dso_dt;

            // kill switch
            if(angle > 60.f*DEG_TO_RAD || angle < -60.f*DEG_TO_RAD) {
                drv8874_set_duty(&drv8874_1_config, 0.0f);
                drv8874_set_duty(&drv8874_2_config, 0.0f);
                shm_tx_payload->is_dead = 1;
                is_dead = true;
            }
        }

        now = tdxtick_get_tick();

        // DRV8874
        if(now >= ctl_loop_next && !is_dead) {
            const float dt = tdxtick_time_diff(ctl_loop_last, now);

            const float dist_1 = COUNTS_TO_METERS*tdxenc_get_counts(encoder_1);
            const float dist_2 = COUNTS_TO_METERS*tdxenc_get_counts(encoder_2);
            dist_avg = 0.5f*(dist_1 + dist_2);

            const float speed_1 = COUNTS_TO_METERS*tdxenc_get_cps(encoder_1);
            const float speed_2 = COUNTS_TO_METERS*tdxenc_get_cps(encoder_2);
            speed_avg = 0.5f*(speed_1 + speed_2);

            feedback_v3(
                &feedback_data_v3,
                &drv8874_1_config, &drv8874_2_config,
                dist_avg, speed_avg,
                angle, ang_vel_smooth,
                0.1f*(dist_2 - dist_1),
                dt,
                &motor_duty,
                &motor_target_speed
            );

            ctl_loop_last  = now;
            ctl_loop_next += ctl_loop_dt;
        }

        now = tdxtick_get_tick();

        if(now >= shm_tx_next) {
            const tdxshm_tx_payload_t tx_payload = {
                .time                = tdxtick_tick_to_sec(now),
                .iter_duration       = 1.0e6f*iter_duration,
                .iter_avg_duration   = 1.0e6f*iter_avg_duration,
                .iter_avg_jitter     = 1.0e6f*iter_avg_jitter,
                .iter_max_duration   = 1.0e6f*iter_max_duration,
                .position            = dist_avg,
                .velocity            = speed_avg,
                .angle               = angle,
                .angular_velocity    = ang_vel,
                .angular_velocity_smooth = ang_vel_smooth,
                .angle_correction    = lsm6dso_drift_compensation_value,
                .accelerometer[0]    = accel_data.x,
                .accelerometer[1]    = accel_data.y,
                .accelerometer[2]    = accel_data.z,
                .gyro[0]             = gyro_data.x,
                .gyro[1]             = gyro_data.y,
                .gyro[2]             = gyro_data.z,
                .right_encoder       = tdxenc_get_counts(encoder_1),
                .left_encoder        = tdxenc_get_counts(encoder_2),
                .motor_duty          = motor_duty,
                .motor_target_speed  = motor_target_speed,
            };

            *shm_tx_payload = tx_payload;
            shm_tx_next += shm_tx_dt;
        }

        now = tdxtick_get_tick();

        if(now >= shm_rx_next) {
            shm_tx_payload->flag = shm_rx_payload->flag;
            shm_rx_next += shm_rx_dt;
        }

        now = tdxtick_get_tick();

        // Uncomment for full iteration measurement
        iter_duration     = tdxtick_time_diff_now(iter_begin);

        const float iter_jitter = iter_duration - iter_avg_duration;
        iter_max_duration = fmaxf(iter_duration, iter_max_duration);
        iter_avg_duration += iter_avg_cst*(iter_duration - iter_avg_duration)*iter_duration;
        iter_avg_jitter   += iter_avg_cst*(fabsf(iter_jitter) - iter_avg_jitter)*iter_duration;

        // Uncomment for full iteration measurement
        iter_begin        = tdxtick_get_tick();
    }

    // Should never get here
    LOG_WARN("somehow got out of main loop");
}


int main() {
    /* Board pin, clock, debug console init */
    /* M7 has its local cache and enabled by default,
     * need to set smart subsystems (0x28000000 ~ 0x3FFFFFFF)
     * non-cacheable before accessing this address region */
    BOARD_InitMemory();

    /* Board specific RDC settings */
    BOARD_RdcInit();

    BOARD_InitBootPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    while(true) {
        if(TDXERR_RECOVERY_MODE()) {
            LOG_INFO("entering recovery");
            LOG_DEBUG("deinitializing everything...");
            deinit_all();
            LOG_DEBUG("deinitialization done");
        } else {
            LOG_DEBUG("init periphs");
            init_periphs();

            // Safeguard after init, may be removed
            tdxtick_wait(tdxtick_sec_to_tick(0.2f));

            LOG_INFO("entering main loop");
            main_loop();
        }
    }

    return 0;
}
