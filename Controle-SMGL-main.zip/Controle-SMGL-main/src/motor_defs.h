
#ifndef MOTOR_DEFS_H
#define MOTOR_DEFS_H

#include "drivers/drv8874.h"

//#define MOTOR_REDUCTION 75.0f
//#define ENCODER_COUNTS_PER_REV 12.0f
#define WHEEL_RADIUS (0.04f)
#define MOTOR_REDUCTION (31.25f)
#define ENCODER_COUNTS_PER_REV (20.0f)
#define MOTOR_COUNTS_PER_REV (MOTOR_REDUCTION*ENCODER_COUNTS_PER_REV)
#define COUNTS_TO_METERS (2.0f*((float)M_PI)*WHEEL_RADIUS/MOTOR_COUNTS_PER_REV)

extern drv8874_config_t drv8874_1_config;
extern drv8874_config_t drv8874_2_config;

#endif // MOTOR_DEFS_H
