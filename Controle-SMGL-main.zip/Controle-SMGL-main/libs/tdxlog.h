#ifndef TDXLOG_H
#define TDXLOG_H

#ifndef LOGGER
// Defines PRINTF
#include "fsl_debug_console.h"
#define LOGGER PRINTF
#endif // LOGGER

// Stringify to convert compile-time numbers to strings
#define LOGGER_STRINGIFY(s) LOGGER_STRINGIFY_EXPAND(s)
#define LOGGER_STRINGIFY_EXPAND(s) #s

// Log levels
#define TDX_LOGLEVEL_QUIET 0
#define TDX_LOGLEVEL_ERROR 1
#define TDX_LOGLEVEL_WARN  2
#define TDX_LOGLEVEL_INFO  3
#define TDX_LOGLEVEL_DEBUG 4
#define TDX_LOGLEVEL_TRACE 5

#ifndef TDX_LOGLEVEL
// loglevel not set, using defaults
#ifdef DEBUG // loglevel not defined but program compiled with -D DEBUG
// Show up to debug messages
#define TDX_LOGLEVEL TDX_LOGLEVEL_DEBUG
#else // loglevel not defined but not a debug build
// Show just warnings and errors
#define TDX_LOGLEVEL TDX_LOGLEVEL_WARN
#endif // DEBUG
#endif // TDX_LOGLEVEL

// Prints the file and line where the macro was expanded ("called")
// for some reason __func__ is not working, but I'll leave the structure here in case we try to fix this
#ifdef __GNUC__
#define TDXLOG_WHERE "[" __FILE__ ":" LOGGER_STRINGIFY(__LINE__) "] "
#else // __GNUC__ not def
#define TDXLOG_WHERE "[" __FILE__ ":" LOGGER_STRINGIFY(__LINE__) "] "
#endif // __GNUC__

#if TDX_LOGLEVEL >= TDX_LOGLEVEL_ERROR
#define LOG_ERROR(fmt, ...) LOGGER(TDXLOG_WHERE "ERROR: " fmt "\r\n", ##__VA_ARGS__)
#else // TDX_LOGLEVEL < TDX_LOGLEVEL_ERROR
// do nothing
#define LOG_ERROR(fmt, ...)
#endif

#if TDX_LOGLEVEL >= TDX_LOGLEVEL_WARN
#define LOG_WARN(fmt, ...) LOGGER(TDXLOG_WHERE "WARNING: " fmt "\r\n", ##__VA_ARGS__)
#else // TDX_LOGLEVEL < TDX_LOGLEVEL_WARN
// do nothing
#define LOG_WARN(fmt, ...)
#endif

#if TDX_LOGLEVEL >= TDX_LOGLEVEL_INFO
#define LOG_INFO(fmt, ...) LOGGER(TDXLOG_WHERE "info: " fmt "\r\n", ##__VA_ARGS__)
#else // TDX_LOGLEVEL < TDX_LOGLEVEL_INFO
// do nothing
#define LOG_INFO(fmt, ...)
#endif

#if TDX_LOGLEVEL >= TDX_LOGLEVEL_DEBUG
#define LOG_DEBUG(fmt, ...) LOGGER(TDXLOG_WHERE "debug: " fmt "\r\n", ##__VA_ARGS__)
#else // TDX_LOGLEVEL < TDX_LOGLEVEL_DEBUG
// do nothing
#define LOG_DEBUG(fmt, ...)
#endif

#if TDX_LOGLEVEL >= TDX_LOGLEVEL_TRACE
#define LOG_TRACE(fmt, ...) LOGGER(TDXLOG_WHERE "trace: " fmt "\r\n", ##__VA_ARGS__)
#else // TDX_LOGLEVEL < TDX_LOGLEVEL_TRACE
// do nothing
#define LOG_TRACE(fmt, ...)
#endif

#endif // TDXLOG_H
