#include "tdxtick.h"

// Register defs
#include "MIMX8ML8_cm7.h"
#include "fsl_common.h"

// Stores the extended time value after systick's 24 bits
volatile uint64_t tdxtick_time_high = 0U;

// Defines the systick handler as our function
#define tdxtime_systick_handler SysTick_Handler

void tdxtime_systick_handler() {
    // Carry to an external variable to extend the time counting range
    // should be good for 730 years instead of 20ms at 800MHz
    tdxtick_time_high += 1<<24;
    SDK_ISR_EXIT_BARRIER;
}

void txdtick_init() {
    // Using entire systic range
    // This func enables the counter, configures the interrups, sets reload value
    SysTick_Config(SysTick_VAL_CURRENT_Msk);
}

uint64_t tdxtick_get_tick() {
    // Adding volatile to variables below to act as a memory barrier, forcing reads and writes
    // and preventing instuction re-ordering

    // Time var for the lower bits, as the higher ones come from tdxtick_time_high
    volatile uint32_t tdxtick_time_low;
    // Stores the value of the upper bits inside the safe loop
    volatile uint64_t tdxtick_time_high_shadow;
    // We may have an overflow while reading the tick, so we are going to use COUNTFLAG to ensure a proper read
    do {
        // Volatile forces no caching between reads, this read resets the COUNTFLAG
        // maybe_unused is a C23 feature, remove if using older compiler
        [[ maybe_unused ]] volatile uint32_t _status = SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk;
        // Read the 24 systick bits, but invert them as this is a down counter
        tdxtick_time_low = SysTick_VAL_CURRENT_Msk - (SysTick->VAL & SysTick_VAL_CURRENT_Msk);
        // Then copy the upper bits as they may change after the check below but before the assignment
        tdxtick_time_high_shadow = tdxtick_time_high;
        // Then check for overflow, and do the reading again if the overflow happened
    } while((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) != 0);
    // After a successful run, return the combination of the lower and higher bits
    return tdxtick_time_high_shadow | tdxtick_time_low;
}

float tdxtick_get_time_f() {
    return ((float)tdxtick_get_tick())/SystemCoreClock;
}

double tdxtick_get_time_d() {
    return ((double)tdxtick_get_tick())/SystemCoreClock;
}

float tdxtick_time_diff_now(uint64_t ref) {
    return ((float)(tdxtick_get_tick() - ref))/SystemCoreClock;
}

float tdxtick_time_diff(uint64_t begin, uint64_t end) {
    return ((float)(end - begin))/SystemCoreClock;
}

float tdxtick_tick_to_sec(uint64_t ticks) {
    return ((float)ticks)/SystemCoreClock;
}

uint64_t tdxtick_sec_to_tick(float secs) {
    return (uint64_t)(secs*SystemCoreClock);
}

void tdxtick_wait(uint64_t ticks) {
    const uint64_t tdxtick_delay_begin = tdxtick_get_tick();
    while(tdxtick_get_tick() - tdxtick_delay_begin < ticks);
}
