#ifndef TDXSHM_H
#define TDXSHM_H

#ifndef SHARED_MEM_TX_ADDRESS
#define SHARED_MEM_TX_ADDRESS 0x40000000
#endif // SHARED_MEM_TX_ADDRESS

#ifndef SHARED_MEM_RX_ADDRESS
#define SHARED_MEM_RX_ADDRESS 0x50000000
#endif // SHARED_MEM_RX_ADDRESS

typedef struct {
    float time;
    float iter_duration;
    float iter_avg_duration;
    float iter_avg_jitter;
    float iter_max_duration;
    float position;
    float velocity;
    float angle;
    float angular_velocity;
    float angular_velocity_smooth;
    float angle_correction;
    float accelerometer[3]; // Accelerometer data: x, y, z axis
    float gyro[3]; // Gyroscope data: x, y, z axis
    float left_encoder; // Left wheel encoder count
    float right_encoder; // Right wheel encoder count
    float flag;
    float motor_duty;
    float motor_target_speed;
    bool is_dead;
} tdxshm_tx_payload_t;

#define TDXSHM_DIR_FORWARD (0x01)
#define TDXSHM_DIR_BACKWARD (0x02)
#define TDXSHM_DIR_LEFT (0x03)
#define TDXSHM_DIR_RIGHT (0x04)

typedef struct {
    float flag;
    // uint8_t new_data;
    // uint8_t direction;
    // float kp;
    // float ki;
    // float kd;
} tdxshm_rx_payload_t;

#endif // TDXSHM_H
