#include "tdxerr.h"

#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>

#include "tdxlog.h"

// Stores the registers' state for an emergency jump
// Declared as extern in tdxerr.h
jmp_buf tdxerr_recovery_env;

const char *tdxerr_translate_kstatus(const int status) {
    switch(status) {
    case kStatus_Success:
        return "success";
    case kStatus_Fail:
        return "error: unspecified";
    case kStatus_ReadOnly:
        return "error: read-only";
    case kStatus_OutOfRange:
        return "error: out of range";
    case kStatus_InvalidArgument:
        return "error: invalid argument";
    case kStatus_Timeout:
        return "error: timeout";
    case kStatus_NoTransferInProgress:
        return "error: no transfer in progress";
    case kStatus_Busy:
        return "error: busy";
    case kStatus_NoData:
        return "error: no data found";
    default:
        return "error: unknown error";
    }
}

const char *tdxerr_translate(const tdxerr_status_t code) {
    // Test for tdxerr errors
    switch(code) {
    case TDX_OK:
        return "ok";
    case TDX_ERROR_GENERIC:
        return "generic error";
    case TDX_ERROR_INVALID:
        return "invalid configuration";
    case TDX_ERROR_UNAVAILABLE:
        return "resource unavailable";
    case TDX_ERROR_ASSERT_FAIL:
        return "constraints not fulfilled";
    case TDX_KSTATUS_BASE:
        break; // Handled later
    }

    // Check for kstatus errors
    if(code & TDX_KSTATUS_BASE) {
        return tdxerr_translate_kstatus(code & ~TDX_KSTATUS_BASE);
    }

    // Not one of our known errors
    return "unknown error";
}
