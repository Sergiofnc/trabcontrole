#include <math.h>
#include "kalman.h"

// Initialize Kalman filter
void kalman_init(kalman_t *k, float initial_angle) {
    k->angle = initial_angle;
    k->bias = 0.0f;
    k->rate = 0.0f;
    k->P[0][0] = 1.0f; k->P[0][1] = 0.0f;
    k->P[1][0] = 0.0f; k->P[1][1] = 1.0f;
    k->Q_angle   = 0.0000001f;
    k->Q_bias    = 0.000001f;
    k->R_measure = 0.01f;
}

// Kalman filter update
float kalman_update(kalman_t *k, float accel_angle, float gyro_rate, float dt) {
    // Step 1: Predict
    k->rate = gyro_rate - k->bias;
    k->angle += dt * k->rate;

    // Update covariance matrix
    k->P[0][0] += dt * (dt*k->P[1][1] - k->P[0][1] - k->P[1][0] + k->Q_angle);
    k->P[0][1] -= dt * k->P[1][1];
    k->P[1][0] -= dt * k->P[1][1];
    k->P[1][1] += k->Q_bias * dt;

    // Step 2: Update with accelerometer measurement
    float y = accel_angle - k->angle;  // Innovation (measurement residual)
    float S = k->P[0][0] + k->R_measure;
    float K[2]; // Kalman gain
    K[0] = k->P[0][0] / S;
    K[1] = k->P[1][0] / S;

    // Update estimate
    k->angle += K[0] * y;
    k->bias  += K[1] * y;

    // Update covariance matrix
    float P00_temp = k->P[0][0];
    float P01_temp = k->P[0][1];

    k->P[0][0] -= K[0] * P00_temp;
    k->P[0][1] -= K[0] * P01_temp;
    k->P[1][0] -= K[1] * P00_temp;
    k->P[1][1] -= K[1] * P01_temp;

    return k->angle;
}

// Convert accelerometer readings to angle
float get_accel_angle(float acc_op, float acc_adj) {
    return atan2f(acc_op, acc_adj);
}
