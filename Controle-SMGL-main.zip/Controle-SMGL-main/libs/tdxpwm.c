#include "tdxpwm.h"

#include "MIMX8ML8_cm7.h"

#include "tdxlog.h"

tdxpwm_cb_t tdxpwm_irq1_handler = NULL;
tdxpwm_cb_t tdxpwm_irq2_handler = NULL;
tdxpwm_cb_t tdxpwm_irq3_handler = NULL;
tdxpwm_cb_t tdxpwm_irq4_handler = NULL;

void PWM1_IRQHandler() {
    tdxpwm_irq1_handler();
    SDK_ISR_EXIT_BARRIER;
}

void PWM2_IRQHandler() {
    tdxpwm_irq2_handler();
    SDK_ISR_EXIT_BARRIER;
}

void PWM3_IRQHandler() {
    tdxpwm_irq3_handler();
    SDK_ISR_EXIT_BARRIER;
}

void PWM4_IRQHandler() {
    tdxpwm_irq4_handler();
    SDK_ISR_EXIT_BARRIER;
}

tdxerr_status_t tdxpwm_try_set_irq_handler(const void* pwm_addr, tdxpwm_cb_t cb_ptr) {
    switch((size_t)pwm_addr) {
    case PWM1_BASE:
        if (tdxpwm_irq1_handler == NULL) {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: setting PWM1 IRQ to 0x%p", cb_ptr);
            tdxpwm_irq1_handler = cb_ptr;
            return TDX_OK;
        } else if(tdxpwm_irq1_handler == cb_ptr) {
            LOG_WARN("tdxpwm_try_set_irq_handler: PWM1 IRQ already set to 0x%p", cb_ptr);
            return TDX_OK;
        } else {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: failed to set PWM1 IRQ to 0x%p as it is already set to 0x%p", cb_ptr, tdxpwm_irq1_handler);
            return TDX_ERROR_UNAVAILABLE;
        }
    case PWM2_BASE:
        if (tdxpwm_irq2_handler == NULL) {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: setting PWM2 IRQ to 0x%p", cb_ptr);
            tdxpwm_irq2_handler = cb_ptr;
            return TDX_OK;
        } else if(tdxpwm_irq2_handler == cb_ptr) {
            LOG_WARN("tdxpwm_try_set_irq_handler: PWM2 IRQ already set to 0x%p", cb_ptr);
            return TDX_OK;
        } else {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: failed to set PWM2 IRQ to 0x%p as it is already set to 0x%p", cb_ptr, tdxpwm_irq2_handler);
            return TDX_ERROR_UNAVAILABLE;
        }
    case PWM3_BASE:
        if (tdxpwm_irq3_handler == NULL) {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: setting PWM3 IRQ to 0x%p", cb_ptr);
            tdxpwm_irq3_handler = cb_ptr;
            return TDX_OK;
        } else if(tdxpwm_irq3_handler == cb_ptr) {
            LOG_WARN("tdxpwm_try_set_irq_handler: PWM3 IRQ already set to 0x%p", cb_ptr);
            return TDX_OK;
        } else {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: failed to set PWM3 IRQ to 0x%p as it is already set to 0x%p", cb_ptr, tdxpwm_irq3_handler);
            return TDX_ERROR_UNAVAILABLE;
        }
    case PWM4_BASE:
        if (tdxpwm_irq4_handler == NULL) {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: setting PWM4 IRQ to 0x%p", cb_ptr);
            tdxpwm_irq4_handler = cb_ptr;
            return TDX_OK;
        } else if(tdxpwm_irq4_handler == cb_ptr) {
            LOG_WARN("tdxpwm_try_set_irq_handler: PWM4 IRQ already set to 0x%p", cb_ptr);
            return TDX_OK;
        } else {
            LOG_DEBUG("tdxpwm_try_set_irq_handler: failed to set PWM4 IRQ to 0x%p as it is already set to 0x%p", cb_ptr, tdxpwm_irq4_handler);
            return TDX_ERROR_UNAVAILABLE;
        }
    default:
        LOG_ERROR("tdxpwm_try_set_irq_handler: invalid pwm device base address 0x%p", pwm_addr);
        return TDX_ERROR_INVALID;
    }
}

void tdxpwm_force_set_irq_handler(const void* pwm_addr, tdxpwm_cb_t cb_ptr) {
    switch((size_t)pwm_addr) {
    case PWM1_BASE:
        tdxpwm_irq1_handler = cb_ptr;
    break;
    case PWM2_BASE:
        tdxpwm_irq2_handler = cb_ptr;
    break;
    case PWM3_BASE:
        tdxpwm_irq3_handler = cb_ptr;
    break;
    case PWM4_BASE:
        tdxpwm_irq4_handler = cb_ptr;
    break;
    default:
        LOG_ERROR("tdxpwm_force_set_irq_handler: invalid pwm device base address 0x%p", pwm_addr);
        TDX_ASSERT(TDX_ERROR_INVALID);
    }
}

void tdxpwm_clear_irq_handler(const void* pwm_addr) {
    switch((size_t)pwm_addr) {
    case PWM1_BASE:
        tdxpwm_irq1_handler = NULL;
    break;
    case PWM2_BASE:
        tdxpwm_irq2_handler = NULL;
    break;
    case PWM3_BASE:
        tdxpwm_irq3_handler = NULL;
    break;
    case PWM4_BASE:
        tdxpwm_irq4_handler = NULL;
    break;
    default:
        LOG_ERROR("tdxpwm_clear_irq_handler: invalid pwm device base address 0x%p", pwm_addr);
        TDX_ASSERT(TDX_ERROR_INVALID);
    }
}

