#ifndef TDXERR_H
#define TDXERR_H

#include <stdbool.h>
#include <setjmp.h>

typedef enum {
    TDX_OK                = 0, // No error
    TDX_ERROR_GENERIC     = 1, // Generic error
    TDX_ERROR_INVALID     = 2, // Invalid configuration
    TDX_ERROR_UNAVAILABLE = 3, // Resource unavailable
    TDX_ERROR_ASSERT_FAIL = 4, // Assert failed
    TDX_KSTATUS_BASE      = 0x00010000, // Base value for kStatus errors
} tdxerr_status_t;

// Stores the registers' state for an emergency jump
extern jmp_buf tdxerr_recovery_env;

// Translate kstatus variables to text for debugging purposes
const char *tdxerr_translate_kstatus(const int status);

const char *tdxerr_translate(const tdxerr_status_t code);

// ASSERTS:
// First we evaluate the expression and get the return code
// Then we convert the returned code to our status code if necessary
// If the returned code was not success
// We log the error
// And jump to the recovery section

// PLEASE ENSURE STAT IS EVALUATED ONLY ONCE
// the use on LOGGER_STRINGIFY does not count

// Asserts the returned kStatus is success, otherwise jumps to recovery section
#define ASSERT_KSTATUS(stat) { \
    const int tdxerr_kstatus_value = (stat); \
    const int tdxerr_status_value = TDX_KSTATUS_BASE | tdxerr_kstatus_value; \
    if(__builtin_expect(kStatus_Success != tdxerr_kstatus_value, 0)) { \
        LOG_ERROR(LOGGER_STRINGIFY(stat) " returned %s", tdxerr_translate_kstatus(tdxerr_kstatus_value)); \
        longjmp(tdxerr_recovery_env, tdxerr_status_value); \
    } \
}

// Asserts the returned code is success, otherwise jumps to recovery section
#define TDX_ASSERT(stat) { \
    const int tdxerr_status_value = (stat); \
    if(__builtin_expect(TDX_OK != (tdxerr_status_value), 0)) { \
        LOG_ERROR(LOGGER_STRINGIFY(stat) " returned %s", tdxerr_translate(tdxerr_status_value)); \
        longjmp(tdxerr_recovery_env, tdxerr_status_value); \
    } \
}

// Asserts the returned value is true, otherwise jumps to recovery section
#define TDX_ASSERT_TRUE(stat) { \
    if(__builtin_expect(!(stat), 0)) { \
        LOG_ERROR(LOGGER_STRINGIFY(stat) " returned 'false' when 'true' was required"); \
        longjmp(tdxerr_recovery_env, TDX_ERROR_ASSERT_FAIL); \
    } \
}

// Asserts the returned code is false, otherwise jumps to recovery section
#define TDX_ASSERT_FALSE(stat) { \
    if(__builtin_expect((stat), 0)) { \
        LOG_ERROR(LOGGER_STRINGIFY(stat) " returned 'true' when 'false' was required"); \
        longjmp(tdxerr_recovery_env, TDX_ERROR_ASSERT_FAIL); \
    } \
}

// Defines the location where the program will return to, in case an error happens
#define TDXERR_RECOVERY_MODE() setjmp(tdxerr_recovery_env)

#endif // TDXERR_H
