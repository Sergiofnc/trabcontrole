#ifndef TDXPWM_H
#define TDXPWM_H

// This lib only fixes the pwm irq management

#include "tdxerr.h"

// Interrupt handler signature
typedef void(*tdxpwm_cb_t)();

// Tries to set cb_ptr as the callback for pwm_addr. Returns 0 if successful.
tdxerr_status_t tdxpwm_try_set_irq_handler(const void *pwm_addr, tdxpwm_cb_t cb_ptr);

// Force set the callback, but throws an error if this is not a known pwm.
void tdxpwm_force_set_irq_handler(const void *pwm_addr, tdxpwm_cb_t cb_ptr);

// Sets the pwm handler for the given pwm to NULL
void tdxpwm_clear_irq_handler(const void *pwm_addr);

#endif // TDXPWM_H
