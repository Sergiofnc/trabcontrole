#ifndef TDXTICK_H
#define TDXTICK_H

#include <inttypes.h>

/* Toradex 64-bit time library
 * This library provides basic time support based on systick
 */

// Increments our extended timer when systick overflows
void tdxtime_systick_handler();

// Configures systick
void txdtick_init();

// Gets the 64-bit time since the systick clock started
uint64_t tdxtick_get_tick();

// Returns time in seconds since the systick timer started
// Returns float which is good for displaying but not for comparisons, specially after an hour
// of executon as milliseconds are out of the significant digits
float tdxtick_get_time_f();

// Returns time in seconds since the systick timer started
// Returns double precision which is good for comparisons but slower than using raw ticks
double tdxtick_get_time_d();

// Returns the time diff from ref until now
float tdxtick_time_diff_now(uint64_t ref);

// Returns the time diff from begin to end
float tdxtick_time_diff(uint64_t begin, uint64_t end);

// Converts integer ticks to floating-point seconds
float tdxtick_tick_to_sec(uint64_t ticks);

// Converts floating-point seconds to integer ticks
uint64_t tdxtick_sec_to_tick(float secs);

// Blocks for the given ammount of ticks
void tdxtick_wait(uint64_t ticks);

#endif // TDXTICK_H
