#ifndef KALMAN_H
#define KALMAN_H

// Kalman filter structure
typedef struct {
    float angle;  // Estimated angle
    float bias;   // Bias correction
    float rate;   // Unbiased angular velocity
    float P[2][2]; // Error covariance matrix
    float Q_angle;  // Process noise variance for angle
    float Q_bias;   // Process noise variance for bias
    float R_measure; // Measurement noise variance
} kalman_t;

// Initialize Kalman filter
void kalman_init(kalman_t *k, float initial_angle);

// Kalman filter update
float kalman_update(kalman_t *k, float accel_angle, float gyro_rate, float dt);

// Convert accelerometer readings to angle
float get_accel_angle(float acc_x, float acc_z);

#endif // KALMAN_H
