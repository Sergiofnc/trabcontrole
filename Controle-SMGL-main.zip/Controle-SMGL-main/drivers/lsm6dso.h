#ifndef LSM6DSO_H
#define LSM6DSO_H

#include <stdbool.h>  // For bool
#include <stddef.h>   // For size_t
#include <inttypes.h> // For uint8_t

#include "fsl_i2c.h"

// Stores accelerometer/gyroscope data for all 3 axis
typedef struct {
    float x;
    float y;
    float z;
} lsm6dso_data_t;

typedef enum {
    LSM6DSO_TRANSFER_IDLE ,
    LSM6DSO_TRANSFER_IN_PROGRESS,
    LSM6DSO_TRANSFER_WAITING_DATA,
    LSM6DSO_TRANSFER_DATA_READY,
} lsm6dso_transfer_state_t;

typedef enum {
    LSM_INITAL_STATE,
    LSM_REQUEST_STATUS,
    LSM_REQUEST_ACCEL_VALUES,
    LSM_UPDATE_ACCEL_RESULTS,
    LSM_REQUEST_GYRO_VALUES,
    LSM_UPDATE_GYRO_RESULTS,
} lsm6dso_fsm_state_t;

typedef enum {
    LSM6DSO_NO_NEW_VALUES,
    LSM6DSO_NEW_ACCEL_DATA,
    LSM6DSO_NEW_GYRO_DATA,
} lsm6dso_fsm_result_t;

typedef struct {
    I2C_Type                 *i2c_base;
    lsm6dso_transfer_state_t  transfer_state;
    i2c_master_handle_t       write_handle;
    i2c_master_handle_t       read_handle;
    uint8_t                  *rawdata;
    size_t                    rawdata_size;
    uint8_t                   status_reg;
    lsm6dso_fsm_state_t       fsm_state;
    uint8_t                   accel_data[6];
    uint8_t                   gyro_data[6];
    bool                      is_accel_ready;
    bool                      is_gyro_ready;
} lsm6dso_t;

lsm6dso_t lsm6dso_new(I2C_Type *i2c_base);

void lsm6dso_write_byte(lsm6dso_t *device, uint8_t reg, uint8_t data);
void lsm6dso_write(lsm6dso_t *device, uint8_t reg, uint8_t *dataptr, size_t size);

uint8_t lsm6dso_read_byte(lsm6dso_t *device, uint8_t reg);
void lsm6dso_read(lsm6dso_t *device, uint8_t reg, uint8_t *outptr, size_t size);

void lsm6dso_write_nonblock(lsm6dso_t *device, uint8_t reg, uint8_t *dataptr, size_t size);
void lsm6dso_read_nonblock(lsm6dso_t *device, uint8_t reg, uint8_t *outptr, size_t size);

void lsm6dso_init(lsm6dso_t *device);

lsm6dso_fsm_result_t lsm6dso_fsm(lsm6dso_t *device, lsm6dso_data_t *outptr);

#endif // LSM6DSO_H
