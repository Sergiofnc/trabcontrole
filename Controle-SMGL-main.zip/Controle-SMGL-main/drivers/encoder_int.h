#ifndef ENCODER_INT_H
#define ENCODER_INT_H

// C libs
#include <stdbool.h>

// Device defs
#include "MIMX8ML8_cm7.h"

// Mcuxpresso includes
#include "fsl_gpio.h"

// Project includes
#include "libs/tdxtick.h"

#define TDXENC_RINGBUF_SLOTS 40
#define TDXENC_ENCODER_MAX 4

typedef struct {
    GPIO_Type *base;
    uint32_t   pin;
    IRQn_Type  irq_n;
} tdxenc_gpio_data_t;

typedef struct {
    int32_t  counts;
    uint64_t time_init;
} tdxenc_ringbuf_t;

typedef struct {
    bool               reverse;
    int                io_state;
    tdxenc_gpio_data_t gpio_a;
    tdxenc_gpio_data_t gpio_b;
    uint_fast8_t       ringbuf_index;
    int32_t            ringbuf_sum;
    int32_t            counts_since_start;
    bool               slot_in_use;
    uint64_t           sampling_window_time;
    tdxenc_ringbuf_t   ringbuf[TDXENC_RINGBUF_SLOTS];
} tdxenc_state_t;

// Returns the encoder instance associated to the provided index
tdxenc_state_t *tdxenc_get(const uint8_t enc_index);

// Creates a new encoder instance.
uint8_t tdxenc_new_enc(
          GPIO_Type *gpio_a_base,
    const uint32_t   gpio_a_pin,
    const IRQn_Type  gpio_a_irqn,
          GPIO_Type *gpio_b_base,
    const uint32_t   gpio_b_pin,
    const IRQn_Type  gpio_b_irqn,
    const bool       reverse,
    const uint64_t   window_duration
);

// Returns the encoder system to the state it was just after initialization.
void tdxenc_deinit();

// Frees encoder slot.
void tdxenc_free(const uint8_t enc_index);

// Returns the encoder counts per second as float.
float tdxenc_get_cps(const uint8_t enc_index);

// Returns the total counts since the encoder initialization or a reference-frame update
int32_t tdxenc_get_counts(const uint8_t enc_index);

// Sets the total distance travelled by the robot to 0
// Returns the value it held before clearing
int32_t tdxenc_update_reference_frame(const uint8_t enc_index);

// Call this from the interrupt handler
void tdxenc_irq_handler();

#endif // ENCODER_INT_H
