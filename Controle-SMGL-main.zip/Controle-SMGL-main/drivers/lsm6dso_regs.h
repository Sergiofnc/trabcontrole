#ifndef LSM6DSO_REGS_H
#define LSM6DSO_REGS_H

#define LSM6DSO_I2C_ADDRESS		 0x6BU

#define FUNC_CFG_ACCESS          0x01
#define PIN_CTRL                 0x02
#define FIFO_CTRL1               0x07
#define FIFO_CTRL2               0x08
#define FIFO_CTRL3               0x09
#define FIFO_CTRL4               0x0A
#define COUNTER_BDR_REG1         0x0B
#define COUNTER_BDR_REG2         0x0C

#define INT1_CTRL                       (0x0DU)
#define INT1_CTRL_INT1_DRDY_XL_OFFSET   (0U)
#define INT1_CTRL_INT1_DRDY_XL          (1 << (INT1_CTRL_INT1_DRDY_XL_OFFSET))
#define INT1_CTRL_INT1_DRDY_G_OFFSET    (1U)
#define INT1_CTRL_INT1_DRDY_G           (1 << (INT1_CTRL_INT1_DRDY_G_OFFSET))
#define INT1_CTRL_INT1_BOOT_OFFSET      (2U)
#define INT1_CTRL_INT1_BOOT             (1 << (INT1_CTRL_INT1_BOOT_OFFSET))
#define INT1_CTRL_INT1_FIFO_TH_OFFSET   (3U)
#define INT1_CTRL_INT1_FIFO_TH          (1 << (INT1_CTRL_INT1_FIFO_TH_OFFSET))
#define INT1_CTRL_INT1_FIFO_OVR_OFFSET  (4U)
#define INT1_CTRL_INT1_FIFO_OVR         (1 << (INT1_CTRL_INT1_FIFO_OVR_OFFSET))
#define INT1_CTRL_INT1_FIFO_FULL_OFFSET (5U)
#define INT1_CTRL_INT1_FIFO_FULL        (1 << (INT1_CTRL_INT1_FIFO_FULL_OFFSET))
#define INT1_CTRL_INT1_INT_BDR_OFFSET   (6U)
#define INT1_CTRL_INT1_INT_BDR          (1 << (INT1_CTRL_INT1_INT_BDR_OFFSET))
#define INT1_CTRL_DEN_DRDY_FLAG_OFFSET  (7U)
#define INT1_CTRL_DEN_DRDY_FLAG         (1 << (INT1_CTRL_DEN_DRDY_FLAG_OFFSET))

#define INT2_CTRL                       (0x0EU)
#define INT2_CTRL_INT2_DRDY_XL_OFFSET   (0U)
#define INT2_CTRL_INT2_DRDY_XL          (1 << (INT2_CTRL_INT2_DRDY_XL_OFFSET))
#define INT2_CTRL_INT2_DRDY_G_OFFSET    (1U)
#define INT2_CTRL_INT2_DRDY_G           (1 << (INT2_CTRL_INT2_DRDY_G_OFFSET))
#define INT2_CTRL_INT2_DRDY_TEMP_OFFSET (2U)
#define INT2_CTRL_INT2_DRDY_TEMP        (1 << (INT2_CTRL_INT2_DRDY_TEMP_OFFSET))
#define INT2_CTRL_INT_FIFO_TH_OFFSET    (3U)
#define INT2_CTRL_INT_FIFO_TH           (1 << (INT2_CTRL_INT_FIFO_TH_OFFSET))
#define INT2_CTRL_INT2_FIFO_OVR_OFFSET  (4U)
#define INT2_CTRL_INT2_FIFO_OVR         (1 << (INT2_CTRL_INT2_FIFO_OVR_OFFSET))
#define INT2_CTRL_INT2_FIFO_FULL_OFFSET (5U)
#define INT2_CTRL_INT2_FIFO_FULL        (1 << (INT2_CTRL_INT2_FIFO_FULL_OFFSET))
#define INT2_CTRL_INT2_CNT_BDR_OFFSET   (6U)
#define INT2_CTRL_INT2_CNT_BDR          (1 << (INT2_CTRL_INT2_CNT_BDR_OFFSET))

// Read-only register. A read operation should return 0x6C.
#define WHO_AM_I                        (0x0FU)

#define CTRL1_XL                        (0x10)
#define CTRL1_XL_LPF2_XL_EN_OFFSET      (1U)
#define CTRL1_XL_LPF2_XL_EN             (1 << (CTRL1_XL_LPF2_XL_EN_OFFSET))
#define CTRL1_XL_FS0_XL_OFFSET          (2U)
#define CTRL1_XL_FS0_XL                 (1 << (CTRL1_XL_FS0_XL_OFFSET))
#define CTRL1_XL_FS1_XL_OFFSET          (3U)
#define CTRL1_XL_FS1_XL                 (1 << (CTRL1_XL_FS1_XL_OFFSET))
#define CTRL1_XL_ODR_XL0_OFFSET         (4U)
#define CTRL1_XL_ODR_XL0                (1 << (CTRL1_XL_ODR_XL0_OFFSET))
#define CTRL1_XL_ODR_XL1_OFFSET         (5U)
#define CTRL1_XL_ODR_XL1                (1 << (CTRL1_XL_ODR_XL1_OFFSET))
#define CTRL1_XL_ODR_XL2_OFFSET         (6U)
#define CTRL1_XL_ODR_XL2                (1 << (CTRL1_XL_ODR_XL2_OFFSET))
#define CTRL1_XL_ODR_XL3_OFFSET         (7U)
#define CTRL1_XL_ODR_XL3                (1 << (CTRL1_XL_ODR_XL3_OFFSET))

#define CTRL2_G                         (0x11U)
#define CTRL2_G_FS_125_OFFSET           (1U)
#define CTRL2_G_FS_125                  (1 << (CTRL2_G_FS_125_OFFSET))
#define CTRL2_G_FS0_G_OFFSET            (2U)
#define CTRL2_G_FS0_G                   (1 << (CTRL2_G_FS0_G_OFFSET))
#define CTRL2_G_FS1_G_OFFSET            (3U)
#define CTRL2_G_FS1_G                   (1 << (CTRL2_G_FS1_G_OFFSET))
#define CTRL2_G_ODR_G0_OFFSET           (4U)
#define CTRL2_G_ODR_G0                  (1 << (CTRL2_G_ODR_G0_OFFSET))
#define CTRL2_G_ODR_G1_OFFSET           (5U)
#define CTRL2_G_ODR_G1                  (1 << (CTRL2_G_ODR_G1_OFFSET))
#define CTRL2_G_ODR_G2_OFFSET           (6U)
#define CTRL2_G_ODR_G2                  (1 << (CTRL2_G_ODR_G2_OFFSET))
#define CTRL2_G_ODR_G3_OFFSET           (7U)
#define CTRL2_G_ODR_G3                  (1 << (CTRL2_G_ODR_G3_OFFSET))

#define CTRL3_C                         (0x12U)
#define CTRL3_C_SW_RESET_OFFSET         (0U)
#define CTRL3_C_SW_RESET                (1 << (CTRL3_C_SW_RESET_OFFSET))
#define CTRL3_C_IF_INC_OFFSET           (2U)
#define CTRL3_C_IF_INC                  (1 << (CTRL3_C_IF_INC_OFFSET))
#define CTRL3_C_SIM_OFFSET              (3U)
#define CTRL3_C_SIM                     (1 << (CTRL3_C_SIM_OFFSET))
#define CTRL3_C_PP_OD_OFFSET            (4U)
#define CTRL3_C_PP_OD                   (1 << (CTRL3_C_PP_OD_OFFSET))
#define CTRL3_C_H_LACTIVE_OFFSET        (5U)
#define CTRL3_C_H_LACTIVE               (1 << (CTRL3_C_H_LACTIVE_OFFSET))
#define CTRL3_C_BDU_OFFSET              (6U)
#define CTRL3_C_BDU                     (1 << (CTRL3_C_BDU_OFFSET))
#define CTRL3_C_BOOT_OFFSET             (7U)
#define CTRL3_C_BOOT                    (1 << (CTRL3_C_BOOT_OFFSET))

#define CTRL4_C                         (0x13)
#define CTRL4_C_LPF1_SEL_G_OFFSET       (1U)
#define CTRL4_C_LPF1_SEL_G              (1 << (CTRL4_C_LPF1_SEL_G_OFFSET))
#define CTRL4_C_I2C_DISABLE_OFFSET      (2U)
#define CTRL4_C_I2C_DISABLE             (1 << (CTRL4_C_I2C_DISABLE_OFFSET))
#define CTRL4_C_DRDY_MASK_OFFSET        (3U)
#define CTRL4_C_DRDY_MASK               (1 << (CTRL4_C_DRDY_MASK_OFFSET))
#define CTRL4_C_INT2_ON_INT1_OFFSET     (5U)
#define CTRL4_C_INT2_ON_INT1            (1 << (CTRL4_C_INT2_ON_INT1_OFFSET))
#define CTRL4_C_SLEEP_G_OFFSET          (6U)
#define CTRL4_C_SLEEP_G                 (1 << (CTRL4_C_SLEEP_G_OFFSET))

#define CTRL5_C                         (0x14)
#define CTRL5_C_ST0_XL_OFFSET           (0U)
#define CTRL5_C_ST0_XL                  (1 << (CTRL5_C_ST0_XL_OFFSET))
#define CTRL5_C_ST1_XL_OFFSET           (1U)
#define CTRL5_C_ST1_XL                  (1 << (CTRL5_C_ST1_XL_OFFSET))
#define CTRL5_C_ST0_G_OFFSET            (2U)
#define CTRL5_C_ST0_G                   (1 << (CTRL5_C_ST0_G_OFFSET))
#define CTRL5_C_ST1_G_OFFSET            (3U)
#define CTRL5_C_ST1_G                   (1 << (CTRL5_C_ST1_G_OFFSET))
#define CTRL5_C_ROUNDING_ACCEL_OFFSET   (5U)
#define CTRL5_C_ROUNDING_ACCEL          (1 << (CTRL5_C_ROUNDING_ACCEL_OFFSET))
#define CTRL5_C_ROUNDING_GYRO_OFFSET    (6U)
#define CTRL5_C_ROUNDING_GYRO           (1 << (CTRL5_C_ROUNDING_GYRO_OFFSET))
#define CTRL5_C_XL_ULP_EN_OFFSET        (7U)
#define CTRL5_C_XL_ULP_EN               (1 << (CTRL5_C_XL_ULP_EN_OFFSET))

#define CTRL6_C                         (0x15)
#define CTRL6_C_FTYPE0_OFFSET           (0U)
#define CTRL6_C_FTYPE0                  (1 << (CTRL6_C_FTYPE0_OFFSET))
#define CTRL6_C_FTYPE1_OFFSET           (1U)
#define CTRL6_C_FTYPE1                  (1 << (CTRL6_C_FTYPE1_OFFSET))
#define CTRL6_C_FTYPE2_OFFSET           (2U)
#define CTRL6_C_FTYPE2                  (1 << (CTRL6_C_FTYPE2_OFFSET))
#define CTRL6_C_USR_OFF_W_OFFSET        (3U)
#define CTRL6_C_USR_OFF_W               (1 << (CTRL6_C_USR_OFF_W_OFFSET))
#define CTRL6_C_XL_HM_MODE_OFFSET       (4U)
#define CTRL6_C_XL_HM_MODE              (1 << (CTRL6_C_XL_HM_MODE_OFFSET))
#define CTRL6_C_LVL2_EN_OFFSET          (5U)
#define CTRL6_C_LVL2_EN                 (1 << (CTRL6_C_LVL2_EN_OFFSET))
#define CTRL6_C_LVL1_EN_OFFSET          (6U)
#define CTRL6_C_LVL1_EN                 (1 << (CTRL6_C_LVL1_EN_OFFSET))
#define CTRL6_C_TRIG_EN_OFFSET          (7U)
#define CTRL6_C_TRIG_EN                 (1 << (CTRL6_C_TRIG_EN_OFFSET))

#define CTRL7_G                         (0x16)
#define CTRL7_G_OIS_ON_OFFSET           (0U)
#define CTRL7_G_OIS_ON                  (1 << (CTRL7_G_OIS_ON_OFFSET))
#define CTRL7_G_USR_OFF_ON_OUT_OFFSET   (1U)
#define CTRL7_G_USR_OFF_ON_OUT          (1 << (CTRL7_G_USR_OFF_ON_OUT_OFFSET))
#define CTRL7_G_OIS_ON_EN_OFFSET        (2U)
#define CTRL7_G_OIS_ON_EN               (1 << (CTRL7_G_OIS_ON_EN_OFFSET))
#define CTRL7_G_HPM_G0_OFFSET           (4U)
#define CTRL7_G_HPM_G0                  (1 << (CTRL7_G_HPM_G0_OFFSET))
#define CTRL7_G_HPM_G1_OFFSET           (5U)
#define CTRL7_G_HPM_G1                  (1 << (CTRL7_G_HPM_G1_OFFSET))
#define CTRL7_G_HP_EN_G_OFFSET          (6U)
#define CTRL7_G_HP_EN_G                 (1 << (CTRL7_G_HP_EN_G_OFFSET))
#define CTRL7_G_G_HM_MODE_OFFSET        (7U)
#define CTRL7_G_G_HM_MODE               (1 << (CTRL7_G_G_HM_MODE_OFFSET))

#define CTRL8_XL                        (0x17)
#define CTRL8_XL_LOW_PASS_ON_6D_OFFSET  (0U)
#define CTRL8_XL_LOW_PASS_ON_6D         (1 << (CTRL8_XL_LOW_PASS_ON_6D_OFFSET))
#define CTRL8_XL_XL_FS_MODE_OFFSET      (1U)
#define CTRL8_XL_XL_FS_MODE             (1 << (CTRL8_XL_XL_FS_MODE_OFFSET))
#define CTRL8_XL_HP_SLOPE_XL_EN_OFFSET  (2U)
#define CTRL8_XL_HP_SLOPE_XL_EN         (1 << (CTRL8_XL_HP_SLOPE_XL_EN_OFFSET))
#define CTRL8_XL_FASTSETTL_MODE_XL_OFFSET (3U)
#define CTRL8_XL_FASTSETTL_MODE_XL        (1 << (CTRL8_XL_FASTSETTL_MODE_XL_OFFSET))
#define CTRL8_XL_HP_REF_MODE_XL_OFFSET  (4U)
#define CTRL8_XL_HP_REF_MODE_XL         (1 << (CTRL8_XL_HP_REF_MODE_XL_OFFSET))
#define CTRL8_XL_HPCF_XL_0_OFFSET       (5U)
#define CTRL8_XL_HPCF_XL_0              (1 << (CTRL8_XL_HPCF_XL_0_OFFSET))
#define CTRL8_XL_HPCF_XL_1_OFFSET       (6U)
#define CTRL8_XL_HPCF_XL_1              (1 << (CTRL8_XL_HPCF_XL_1_OFFSET))
#define CTRL8_XL_HPCF_XL_2_OFFSET       (7U)
#define CTRL8_XL_HPCF_XL_2              (1 << (CTRL8_XL_HPCF_XL_2_OFFSET))

#define CTRL9_XL                        (0x18)
#define CTRL9_XL_I3C_DISABLE_OFFSET     (1U)
#define CTRL9_XL_I3C_DISABLE            (1 << (CTRL9_XL_I3C_DISABLE_OFFSET))
#define CTRL9_XL_DEN_LH_OFFSET          (2U)
#define CTRL9_XL_DEN_LH                 (1 << (CTRL9_XL_DEN_LH_OFFSET))
#define CTRL9_XL_DEN_XL_EN_OFFSET       (3U)
#define CTRL9_XL_DEN_XL_EN              (1 << (CTRL9_XL_DEN_XL_EN_OFFSET))
#define CTRL9_XL_DEN_XL_G_OFFSET        (4U)
#define CTRL9_XL_DEN_XL_G               (1 << (CTRL9_XL_DEN_XL_G_OFFSET))
#define CTRL9_XL_DEN_Z_OFFSET           (5U)
#define CTRL9_XL_DEN_Z                  (1 << (CTRL9_XL_DEN_Z_OFFSET))
#define CTRL9_XL_DEN_Y_OFFSET           (6U)
#define CTRL9_XL_DEN_Y                  (1 << (CTRL9_XL_DEN_Y_OFFSET))
#define CTRL9_XL_DEN_X_OFFSET           (7U)
#define CTRL9_XL_DEN_X                  (1 << (CTRL9_XL_DEN_X_OFFSET))

#define CTRL10_C                        (0x19)
#define CTRL10_C_TIMESTAMP_EN_OFFSET    (5U)
#define CTRL10_C_TIMESTAMP_EN           (1 << (CTRL10_C_TIMESTAMP_EN_OFFSET))

#define ALL_INT_SRC                     0x1A

#define WAKE_UP_SRC                     0x1B

#define TAP_SRC                         0x1C

#define D6D_SRC                         0x1D
#define D6D_SRC_XL_OFFSET               (0U)
#define D6D_SRC_XL                      (1 << (D6D_SRC_XL_OFFSET))
#define D6D_SRC_XH_OFFSET               (1U)
#define D6D_SRC_XH                      (1 << (D6D_SRC_XH_OFFSET))
#define D6D_SRC_YL_OFFSET               (2U)
#define D6D_SRC_YL                      (1 << (D6D_SRC_YL_OFFSET))
#define D6D_SRC_YH_OFFSET               (3U)
#define D6D_SRC_YH                      (1 << (D6D_SRC_YH_OFFSET))
#define D6D_SRC_ZL_OFFSET               (4U)
#define D6D_SRC_ZL                      (1 << (D6D_SRC_ZL_OFFSET))
#define D6D_SRC_ZH_OFFSET               (5U)
#define D6D_SRC_ZH                      (1 << (D6D_SRC_ZH_OFFSET))
#define D6D_SRC_D6D_IA_OFFSET           (6U)
#define D6D_SRC_D6D_IA                  (1 << (D6D_SRC_D6D_IA_OFFSET))
#define D6D_SRC_DEN_DRDY_OFFSET         (7U)
#define D6D_SRC_DEN_DRDY                (1 << (D6D_SRC_DEN_DRDY_OFFSET))

#define STATUS_REG                      (0x1E)
#define STATUS_REG_XLDA_OFFSET          (0U)
#define STATUS_REG_XLDA                 (1 << (STATUS_REG_XLDA_OFFSET))
#define STATUS_REG_GDA_OFFSET           (1U)
#define STATUS_REG_GDA                  (1 << (STATUS_REG_GDA_OFFSET))
#define STATUS_REG_TDA_OFFSET           (2U)
#define STATUS_REG_TDA                  (1 << (STATUS_REG_TDA_OFFSET))

#define OUT_TEMP_L               0x20
#define OUT_TEMP_H               0x21
#define OUTX_L_G                 0x22 // Gyro sensor pitch axis (X) D0-D7
#define OUTX_H_G                 0x23 // Gyro sensor pitch axis (X) D8-D15
#define OUTY_L_G                 0x24 // Gyro sensor pitch axis (Y) D0-D7
#define OUTY_H_G                 0x25 // Gyro sensor pitch axis (Y) D8-D15
#define OUTZ_L_G                 0x26 // Gyro sensor pitch axis (z) D0-D7 
#define OUTZ_H_G                 0x27 // Gyro sensor pitch axis (z) D8-D15 
#define OUTX_L_A                 0x28 // Accelerometer sensor pitch axis (X) D0-D7
#define OUTX_H_A                 0x29 // Accelerometer sensor pitch axis (X) D8-D15
#define OUTY_L_A                 0x2A // Accelerometer sensor pitch axis (Y) D0-D7
#define OUTY_H_A                 0x2B // Accelerometer sensor pitch axis (Y) D8-D15
#define OUTZ_L_A                 0x2C // Accelerometer sensor pitch axis (z) D0-D7
#define OUTZ_H_A                 0x2D // Accelerometer sensor pitch axis (z) D8-D15
#define EMB_FUNC_STATUS_MAINPAGE 0x35
#define FSM_STATUS_A_MAINPAGE    0x36
#define FSM_STATUS_B_MAINPAGE    0x37
#define STATUS_MASTER_MAINPAGE   0x39
#define FIFO_STATUS1             0x3A
#define FIFO_STATUS2             0x3B
#define TIMESTAMP0               0x40
#define TIMESTAMP1               0x41
#define TIMESTAMP2               0x42
#define TIMESTAMP3               0x43
#define TAP_CFG0                 0x56
#define TAP_CFG1                 0x57
#define TAP_CFG2                 0x58
#define TAP_THS_6D               0x59
#define INT_DUR2                 0x5A
#define WAKE_UP_THS              0x5B
#define WAKE_UP_DUR              0x5C
#define FREE_FALL                0x5D
#define MD1_CFG                  0x5E
#define MD2_CFG                  0x5F
#define I3C_BUS_AVB              0x62
#define INTERNAL_FREQ_FINE       0x63
#define LSM6DSO_ID               0x6C
#define INT_OIS                  0x6F
#define CTRL1_OIS                0x70
#define CTRL2_OIS                0x71
#define CTRL3_OIS                0x72
#define X_OFS_USR                0x73
#define Y_OFS_USR                0x74
#define Z_OFS_USR                0x75
#define FIFO_DATA_OUT_TAG        0x78
#define FIFO_DATA_OUT_X_L        0x79
#define FIFO_DATA_OUT_X_H        0x7A
#define FIFO_DATA_OUT_Y_L        0x7B
#define FIFO_DATA_OUT_Y_H        0x7C
#define FIFO_DATA_OUT_Z_L        0x7D
#define FIFO_DATA_OUT_Z_H        0x7E

#endif // LSM6DSO_REGS_H
