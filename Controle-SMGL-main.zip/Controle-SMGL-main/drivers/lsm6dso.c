#include "lsm6dso.h"
#include "lsm6dso_regs.h"

#include "MIMX8ML8_cm7.h"

#include <math.h>

// Configuring log levels
#ifdef LSM6DSO_DBG
#define TDX_LOGLEVEL TDX_LOGLEVEL_TRACE
#endif

// Logging
#include "libs/tdxlog.h"
#include "libs/tdxerr.h"

#define DEG_TO_RAD (((float)M_PI)/180.f)

static void lsm6dso_i2c_write_done(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *device) {
    ASSERT_KSTATUS(status);
    LOG_TRACE("in write done");
    ((lsm6dso_t*)device)->transfer_state = LSM6DSO_TRANSFER_IDLE;
}

static void lsm6dso_i2c_read_done(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *device) {
    ASSERT_KSTATUS(status);
    LOG_TRACE("in read done");
    ((lsm6dso_t*)device)->transfer_state = LSM6DSO_TRANSFER_DATA_READY;
}

lsm6dso_t lsm6dso_new(I2C_Type *i2c_base) {
    i2c_master_handle_t i2c_master_handle;
    memset(&i2c_master_handle, 0, sizeof(i2c_master_handle));

    lsm6dso_t lsm6dso_data = {
        .i2c_base       = i2c_base,
        .transfer_state = LSM6DSO_TRANSFER_IDLE,
        .write_handle   = i2c_master_handle,
        .read_handle    = i2c_master_handle,
        .rawdata        = NULL,
        .rawdata_size   = 0U,
        .fsm_state      = LSM_INITAL_STATE,
        .is_accel_ready = false,
        .is_gyro_ready  = false,
    };

    lsm6dso_init(&lsm6dso_data);

    return lsm6dso_data;
}

bool lsm6dso_is_ready(const lsm6dso_t *device) {
    return device->transfer_state == LSM6DSO_TRANSFER_IDLE ||
        device->transfer_state == LSM6DSO_TRANSFER_DATA_READY;
}

bool lsm6dso_i2c_data_received(const lsm6dso_t *device) {
    // If we are on idle then the transfer is done but was not a read op, so we are never
    // reaching data_ready status
    TDX_ASSERT_TRUE(device->transfer_state != LSM6DSO_TRANSFER_IDLE);
    return device->transfer_state == LSM6DSO_TRANSFER_DATA_READY;
}

void lsm6dso_write_byte(lsm6dso_t *device, uint8_t reg, uint8_t data) {
    i2c_master_transfer_t master_transfer = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = &data,
        .dataSize       = 1,
        .flags          = kI2C_TransferDefaultFlag,
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &master_transfer));
}

void lsm6dso_write(lsm6dso_t *device, uint8_t reg, uint8_t *dataptr, size_t size) {
    i2c_master_transfer_t master_transfer = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = dataptr,
        .dataSize       = size,
        .flags          = kI2C_TransferDefaultFlag,
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &master_transfer));
}

uint8_t lsm6dso_read_byte(lsm6dso_t *device, uint8_t reg) {
    // First, set up the device register to read from
    i2c_master_transfer_t transf_send_address = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = NULL, // No data to write
        .dataSize       = 0, // No data size for write phase
        .flags          = kI2C_TransferNoStopFlag, // Indicate no stop condition after write
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &transf_send_address));

    // The "buffer" to save the data
    uint8_t outdata = 0;

    // Now, read from the device
    i2c_master_transfer_t transf_data_read = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Read,
        .subaddress     = (uint32_t)NULL,
        .subaddressSize = 0, // No subaddress needed for read phase
        .data           = &outdata,
        .dataSize       = sizeof(outdata),
        .flags          = kI2C_TransferRepeatedStartFlag, // Use repeated start for the read
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &transf_data_read));

    // Return our "buffer" content
    return outdata;
}

void lsm6dso_read(lsm6dso_t *device, uint8_t reg, uint8_t *outptr, size_t size) {
    // First, set up the device register to read from
    i2c_master_transfer_t transf_send_address = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = NULL, // No data to write
        .dataSize       = 0, // No data size for write phase
        .flags          = kI2C_TransferNoStopFlag, // Indicate no stop condition after write
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &transf_send_address));

    // Now, read from the device
    i2c_master_transfer_t transf_data_read = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Read,
        .subaddress     = (uint32_t)NULL,
        .subaddressSize = 0, // No subaddress needed for read phase
        .data           = outptr,
        .dataSize       = size,
        .flags          = kI2C_TransferRepeatedStartFlag, // Use repeated start for the read
    };

    ASSERT_KSTATUS(I2C_MasterTransferBlocking(device->i2c_base, &transf_data_read));
}

void lsm6dso_write_nonblock(lsm6dso_t *device, uint8_t reg, uint8_t *dataptr, size_t size) {
    TDX_ASSERT_TRUE(lsm6dso_is_ready(device));

    // Block other requests to this device until this transfer is done
    device->transfer_state = LSM6DSO_TRANSFER_IN_PROGRESS;

    i2c_master_transfer_t transf_send_data = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = dataptr,
        .dataSize       = size,
        .flags          = kI2C_TransferDefaultFlag,
    };

    I2C_MasterTransferCreateHandle(device->i2c_base, &device->write_handle, lsm6dso_i2c_write_done, device);
    I2C_MasterTransferNonBlocking(device->i2c_base, &device->write_handle, &transf_send_data);
}

static void lsm6dso_read_nonblock_cb(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *device) {
    LOG_TRACE("in lsm6dso_read_nonblock_cb");
    // Update blocking status
    ((lsm6dso_t*)device)->transfer_state = LSM6DSO_TRANSFER_WAITING_DATA;

    // Now, read from the device
    i2c_master_transfer_t transf_data_read = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Read,
        .subaddress     = (uint32_t)NULL,
        .subaddressSize = 0, // No subaddress needed for read phase
        .data           = ((lsm6dso_t*)device)->rawdata,
        .dataSize       = ((lsm6dso_t*)device)->rawdata_size,
        .flags          = kI2C_TransferRepeatedStartFlag, // Use repeated start for the read
    };

    // master transfer is cached, so we dont have to worry about accessing garbage
    I2C_MasterTransferCreateHandle(((lsm6dso_t*)device)->i2c_base, &((lsm6dso_t*)device)->read_handle, lsm6dso_i2c_read_done, device);
    I2C_MasterTransferNonBlocking(((lsm6dso_t*)device)->i2c_base, &((lsm6dso_t*)device)->read_handle, &transf_data_read);
}

void lsm6dso_read_nonblock(lsm6dso_t *device, uint8_t reg, uint8_t *outptr, size_t size) {
    TDX_ASSERT_TRUE(lsm6dso_is_ready(device));

    // Block other requests to this device until this transfer is done
    device->transfer_state = LSM6DSO_TRANSFER_IN_PROGRESS;

    // First, set up the device register to read from
    i2c_master_transfer_t transf_send_address = {
        .slaveAddress   = LSM6DSO_I2C_ADDRESS,
        .direction      = kI2C_Write,
        .subaddress     = (uint32_t)reg,
        .subaddressSize = 1,
        .data           = NULL, // No data to write
        .dataSize       = 0, // No data size for write phase
        .flags          = kI2C_TransferNoStopFlag, // Indicate no stop condition after write
    };

    device->rawdata      = outptr;
    device->rawdata_size = size;

    I2C_MasterTransferCreateHandle(device->i2c_base, &device->write_handle, lsm6dso_read_nonblock_cb, device);
    I2C_MasterTransferNonBlocking(device->i2c_base, &device->write_handle, &transf_send_address);
}

void lsm6dso_init(lsm6dso_t *device) {
    // Assert we are talking to a LSM6DSO
    LOG_DEBUG("requesting id (%u) from I2C device at %u", (uint8_t)WHO_AM_I, (uint8_t)LSM6DSO_I2C_ADDRESS);
    LOG_TRACE("this read will block forever if the accelerometer is not connected");
    TDX_ASSERT_TRUE(lsm6dso_read_byte(device, WHO_AM_I) == LSM6DSO_ID);
    LOG_DEBUG("LSM6DSO accelerometer found");

    // Configure Accelerometer
    LOG_DEBUG("configuring accelerometer regs");

    // No use for INT1 pin
    lsm6dso_write_byte(device, INT1_CTRL, 0x00);

    // ODR_XL     = 0b0101 => 208Hz LPF
    // FS_XL      = 0b00   => 2g range
    // LPF2_XL_EN = 0b0    => single stage filter
    lsm6dso_write_byte(device, CTRL1_XL, CTRL1_XL_ODR_XL2 | CTRL1_XL_ODR_XL0);
    
    // Configure Gyroscope
    LOG_DEBUG("configuring gyro regs");

    // ODR_G      = 0b0111 => 833Hz LPF (further reduced to 295.5Hz in LPF2)
    // FS_G       = 0b01   => 500 degrees per second range
    // FS_125     = 0b0    => using FS_G config
    lsm6dso_write_byte(device, CTRL2_G, CTRL2_G_ODR_G2 | CTRL2_G_ODR_G1 | CTRL2_G_ODR_G0 | CTRL2_G_FS0_G);

    // BOOT       = 0b0    => No reboot
    // BDU        = 0b0    => No data block
    // H_LACTIVE  = 0b0    => Interrupts active high
    // PP_OD      = 0b0    => Interrupts are push-pull
    // SIM        = 0b0    => Default, 4-wire SPI
    // IF_INC     = 0b1    => Auto increment position on read
    // SW_RESET   = 0b0    => No soft reset
    lsm6dso_write_byte(device, CTRL3_C, CTRL3_C_IF_INC);

    // G_HM_MODE  = 0b0    => High-performance mode
    // HP_EN_G    = 0b1    => High-pass enabled
    // HPM_G      = 0b00   => High pass cutoff at 16mHz
    // OIS_ON_EN  = 0b0    => OIS config, unused
    // USR_OFF_ON_OUT = 0b0 => No user accelerometer offset correction
    // OIS_ON     = 0b0    => OIS disabled
    lsm6dso_write_byte(device, CTRL7_G, CTRL7_G_HP_EN_G);

    LOG_DEBUG("LSM6DSO init done");
}

static float lsm6dso_convert_data(uint8_t low, uint8_t high, float cst) {
    const int16_t data_16bit = (((int16_t)high) << 8) | low;
    return cst*((float)data_16bit);
}

lsm6dso_fsm_result_t lsm6dso_fsm(lsm6dso_t *device, lsm6dso_data_t *outptr) {
    if(lsm6dso_is_ready(device) == false) return LSM6DSO_NO_NEW_VALUES;

    switch(device->fsm_state) {
    case LSM_INITAL_STATE:
        LOG_TRACE("lsm6dso_fsm: LSM_INITAL_STATE -> LSM_REQUEST_STATUS");
        device->fsm_state = LSM_REQUEST_STATUS;
        return LSM6DSO_NO_NEW_VALUES;

    case LSM_REQUEST_STATUS:
        LOG_TRACE("lsm6dso_fsm: LSM_REQUEST_STATUS -> LSM_REQUEST_ACCEL_VALUES");
        lsm6dso_read_nonblock(device, STATUS_REG, &device->status_reg, 1U);
        device->fsm_state = LSM_REQUEST_ACCEL_VALUES;
        return LSM6DSO_NO_NEW_VALUES;

    case LSM_REQUEST_ACCEL_VALUES:
        // Check if the accel has data
        if(device->status_reg & STATUS_REG_XLDA) {
            LOG_TRACE("lsm6dso_fsm: LSM_REQUEST_ACCEL_VALUES -> LSM_UPDATE_ACCEL_RESULTS");
            lsm6dso_read_nonblock(device, OUTX_L_A, device->accel_data, 6U);
            device->fsm_state = LSM_UPDATE_ACCEL_RESULTS;
        } else {
            LOG_TRACE("lsm6dso_fsm: LSM_REQUEST_ACCEL_VALUES -> LSM_REQUEST_GYRO_VALUES");
            device->fsm_state = LSM_REQUEST_GYRO_VALUES;

            // Re-trigger this function to speed things up
            // as we didn't spend any time processing stuff or waiting
            return lsm6dso_fsm(device, outptr);
        }
        return LSM6DSO_NO_NEW_VALUES;

    case LSM_UPDATE_ACCEL_RESULTS:
        LOG_TRACE("lsm6dso_fsm: LSM_UPDATE_ACCEL_RESULTS -> LSM_REQUEST_GYRO_VALUES");
        // 0.061mg/LSB comes from 2g accel range (FS_XL = 0b00)
        const lsm6dso_data_t accel_results = {
            .x = lsm6dso_convert_data(device->accel_data[0], device->accel_data[1], 9.8f*0.061e-3f),
            .y = lsm6dso_convert_data(device->accel_data[2], device->accel_data[3], 9.8f*0.061e-3f),
            .z = lsm6dso_convert_data(device->accel_data[4], device->accel_data[5], 9.8f*0.061e-3f),
        };
        *outptr = accel_results;
        device->fsm_state = LSM_REQUEST_GYRO_VALUES;
        return LSM6DSO_NEW_ACCEL_DATA;

    case LSM_REQUEST_GYRO_VALUES:
        // Check if the gyro has data
        if(device->status_reg & STATUS_REG_GDA) {
            LOG_TRACE("lsm6dso_fsm: LSM_REQUEST_GYRO_VALUES -> LSM_UPDATE_GYRO_RESULTS");
            lsm6dso_read_nonblock(device, OUTX_L_G, device->gyro_data, 6U);
            device->fsm_state = LSM_UPDATE_GYRO_RESULTS;
        } else {
            LOG_TRACE("lsm6dso_fsm: LSM_REQUEST_GYRO_VALUES -> LSM_REQUEST_STATUS");
            device->fsm_state = LSM_REQUEST_STATUS;

            // Re-trigger this function to speed things up
            // as we didn't spend any time processing stuff or waiting
            return lsm6dso_fsm(device, outptr);
        }
        return LSM6DSO_NO_NEW_VALUES;

    case LSM_UPDATE_GYRO_RESULTS:
        LOG_TRACE("lsm6dso_fsm: LSM_UPDATE_GYRO_RESULTS -> LSM_REQUEST_STATUS");
        // 17.50mdps/LSB comes from 500dps range (FS_G = 0b01 with FS_125 = 0b0)
        const lsm6dso_data_t gyro_results = {
            .x = lsm6dso_convert_data(device->gyro_data[0], device->gyro_data[1], 17.50e-3f*DEG_TO_RAD),
            .y = lsm6dso_convert_data(device->gyro_data[2], device->gyro_data[3], 17.50e-3f*DEG_TO_RAD),
            .z = lsm6dso_convert_data(device->gyro_data[4], device->gyro_data[5], 17.50e-3f*DEG_TO_RAD),
        };
        *outptr = gyro_results;
        device->fsm_state = LSM_REQUEST_STATUS;
        return LSM6DSO_NEW_GYRO_DATA;

    default:
        LOG_ERROR("lsm6dso_fsm: invalid state %d", device->fsm_state);
        device->fsm_state = LSM_INITAL_STATE;
        TDX_ASSERT(TDX_ERROR_INVALID);
        return LSM6DSO_NO_NEW_VALUES;
    }
}
