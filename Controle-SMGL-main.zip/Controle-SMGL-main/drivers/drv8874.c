#include "drv8874.h"

#include <inttypes.h>

// NXP defs
#include "fsl_gpio.h"
#include "fsl_pwm.h"
#include "fsl_common.h"

// Log level override only for this file
//#define TDX_LOGLEVEL TDX_LOGLEVEL_TRACE

// Configuring log levels
#ifdef DRV8874_DBG
#define TDX_LOGLEVEL TDX_LOGLEVEL_TRACE
#endif

// Logging
#include "libs/tdxlog.h"
#include "libs/tdxerr.h"
#include "libs/tdxpwm.h"

#ifndef DRV8874_CLK_SRC
#define DRV8874_CLK_SRC kPWM_HighFrequencyClock
#endif // DRV8874_CLK_SRC

#ifndef DRV8874_CLK_FREQ
#define DRV8874_CLK_FREQ 24000000
#endif // DRV8874_CLK_FREQ

#ifndef DRV8874_PWM_PERIOD
#define DRV8874_PWM_PERIOD 600
#endif // DRV8874_PWM_PERIOD

#define DRV8874_PRESCALER_MAX (1<<12)

// The irq_data address for each pwm interrupt
#define DRV8874_PWM1 0
#define DRV8874_PWM2 1
#define DRV8874_PWM3 2
#define DRV8874_PWM4 3

// A way for the interrupts to read the duty
typedef struct {
    uint32_t duty;
} drv8874_irq_data_t;

drv8874_irq_data_t drv8874_irq_data[4];

// IRQ Handlers

void drv8874_pwm1_irq_handler(void) {
    LOG_TRACE("in PWM1 IRQ handler");
    /* Write duty cycle to PWM sample register. */
    PWM_SetSampleValue(PWM1, drv8874_irq_data[DRV8874_PWM1].duty);
    /* Clear kPWM_FIFOEmptyFlag */
    PWM_clearStatusFlags(PWM1, kPWM_FIFOEmptyFlag);
    SDK_ISR_EXIT_BARRIER;
}

void drv8874_pwm2_irq_handler(void) {
    LOG_TRACE("in PWM1 IRQ handler");
    /* Write duty cycle to PWM sample register. */
    PWM_SetSampleValue(PWM2, drv8874_irq_data[DRV8874_PWM2].duty);
    /* Clear kPWM_FIFOEmptyFlag */
    PWM_clearStatusFlags(PWM2, kPWM_FIFOEmptyFlag);
    SDK_ISR_EXIT_BARRIER;
}

void drv8874_pwm3_irq_handler(void) {
    LOG_TRACE("in PWM1 IRQ handler");
    /* Write duty cycle to PWM sample register. */
    PWM_SetSampleValue(PWM3, drv8874_irq_data[DRV8874_PWM3].duty);
    /* Clear kPWM_FIFOEmptyFlag */
    PWM_clearStatusFlags(PWM3, kPWM_FIFOEmptyFlag);
    SDK_ISR_EXIT_BARRIER;
}

void drv8874_pwm4_irq_handler(void) {
    LOG_TRACE("in PWM1 IRQ handler");
    /* Write duty cycle to PWM sample register. */
    PWM_SetSampleValue(PWM4, drv8874_irq_data[DRV8874_PWM4].duty);
    /* Clear kPWM_FIFOEmptyFlag */
    PWM_clearStatusFlags(PWM4, kPWM_FIFOEmptyFlag);
    SDK_ISR_EXIT_BARRIER;
}

static void drv8874_init_pwm(PWM_Type *base, const uint32_t freq) {
    TDX_ASSERT_TRUE(freq > 0);

    LOG_DEBUG("initializing PWM 0x%p at %" PRIu32 "Hz", base, freq);

    const double prescaler_fp = ((double)DRV8874_CLK_FREQ)/((double)DRV8874_PWM_PERIOD)/freq - 1;
    uint32_t prescaler = (uint32_t)(prescaler_fp + 0.5);

    // Ensure we are not overflowing the prescaler
    TDX_ASSERT_TRUE(prescaler < DRV8874_PRESCALER_MAX);

    LOG_DEBUG("PWM 0x%p prescaler is %" PRIu32, base, prescaler);
    LOG_DEBUG("PWM 0x%p period is %" PRIu32 " clocks", base, (uint32_t)DRV8874_PWM_PERIOD);

    /* PWMCR configuration */
    pwm_config_t pwm_config = {
        .enableStopMode  = false,
        .enableDozeMode  = false,
        .enableWaitMode  = false,
        .enableDebugMode = false,
        .clockSource     = DRV8874_CLK_SRC,
        .prescale        = prescaler,
        .outputConfig    = kPWM_SetAtRolloverAndClearAtcomparison,
        .fifoWater       = kPWM_FIFOWaterMark_2,
        .sampleRepeat    = kPWM_EachSampleOnce,
        .byteSwap        = kPWM_ByteNoSwap,
        .halfWordSwap    = kPWM_HalfWordNoSwap,
    };

    //PWM_SoftwareReset(base); // Make sure that all the registers have the default values
    //PWM_StopTimer(base); // Setting PWMCR[0] = 0 -> stop PWM sign

    ASSERT_KSTATUS(PWM_Init(base, &pwm_config));
    LOG_INFO("PWM configured and initialized");

    /* Enable FIFO empty interrupt */
    PWM_EnableInterrupts(base, kPWM_FIFOEmptyInterruptEnable);

    /* Send three initial samples */
    PWM_SetSampleValue(base, 0);
    PWM_SetSampleValue(base, 0);
    PWM_SetSampleValue(base, 0);

    /* Check and Clear interrupt status flags */
    if (PWM_GetStatusFlags(base)) {
        PWM_clearStatusFlags(base, kPWM_FIFOEmptyFlag | kPWM_RolloverFlag | kPWM_CompareFlag | kPWM_FIFOWriteErrorFlag);
    }

    // Period - 2 as stated in the docs
    PWM_SetPeriodValue(base, DRV8874_PWM_PERIOD - 2);

    // TEST ONLY
	/* Enable interrupt */
    switch((size_t)base) {
    case PWM1_BASE:
        TDX_ASSERT(tdxpwm_try_set_irq_handler(base, drv8874_pwm1_irq_handler));
        EnableIRQ(PWM1_IRQn);
        break;
    case PWM2_BASE:
        TDX_ASSERT(tdxpwm_try_set_irq_handler(base, drv8874_pwm2_irq_handler));
        EnableIRQ(PWM2_IRQn);
        break;
    case PWM3_BASE:
        TDX_ASSERT(tdxpwm_try_set_irq_handler(base, drv8874_pwm3_irq_handler));
        EnableIRQ(PWM3_IRQn);
        break;
    case PWM4_BASE:
        TDX_ASSERT(tdxpwm_try_set_irq_handler(base, drv8874_pwm4_irq_handler));
        EnableIRQ(PWM4_IRQn);
        break;
    }

    PWM_StartTimer(base);
}

// Initialize the DRV8874 motor driver
void drv8874_init(drv8874_config_t *config, const uint32_t freq) {
    const gpio_pin_config_t pin_config_output = {
        .direction     = kGPIO_DigitalOutput,
        .outputLogic   = 0,
        .interruptMode = kGPIO_NoIntmode,
    };

    LOG_WARN("drv8874_init: setting pin %u of gpio 0x%p as nSLEEP output with no interrupts", config->nsleep_pin, config->nsleep_base);
    GPIO_PinInit(config->nsleep_base, config->nsleep_pin, &pin_config_output);

    LOG_WARN("drv8874_init: setting pin %u of gpio 0x%p as PH output with no interrupts", config->ph_pin, config->ph_base);
    GPIO_PinInit(config->ph_base, config->ph_pin, &pin_config_output);

    drv8874_init_pwm(config->pwm_base, freq);
    drv8874_set_duty(config, 0.0f);

    LOG_WARN("drv8874_init: disabling sleep mode");
    GPIO_PinWrite(config->nsleep_base, config->nsleep_pin, 1U);
}

void drv8874_set_duty(drv8874_config_t *config, float percent) {
    LOG_TRACE("drv8874_set_duty: setting PWM 0x%p duty to %f", config->pwm_base, percent);

    const uint8_t dir_positive = config->reverse ? 0 : 1;
    const uint8_t dir_negative = config->reverse ? 1 : 0;

    // Check for negative percentage
    if (percent < 0.0f) {
        percent = -percent;
        GPIO_PinWrite(config->ph_base, config->ph_pin, dir_negative);
    } else {
        GPIO_PinWrite(config->ph_base, config->ph_pin, dir_positive);
    }

    // Saturate percent
    if(percent > 100.0f) percent = 100.0f;

    // Convert percent to duty
    // The -4 is purelly empiric. -3..0 do not set the IO to high on overflow.
    uint32_t duty_cnt = 0.01f*percent*(DRV8874_PWM_PERIOD - 4) + 0.5f;

    // Saturate duty_cnt just in case
    if(duty_cnt > DRV8874_PWM_PERIOD - 4) duty_cnt = DRV8874_PWM_PERIOD - 4;

    switch((size_t)config->pwm_base) {
    case PWM1_BASE:
        LOG_TRACE("drv8874_set_duty: setting PWM1 duty to %" PRIu32 " of %" PRIu32 "(%" PRIu32 "\%)", duty_cnt, (uint32_t)DRV8874_PWM_PERIOD, duty_cnt/DRV8874_PWM_PERIOD);
        drv8874_irq_data[DRV8874_PWM1].duty = duty_cnt;
        break;
    case PWM2_BASE:
        LOG_TRACE("drv8874_set_duty: setting PWM2 duty to %" PRIu32 " of %" PRIu32 "(%" PRIu32 "\%)", duty_cnt, (uint32_t)DRV8874_PWM_PERIOD, duty_cnt/DRV8874_PWM_PERIOD);
        drv8874_irq_data[DRV8874_PWM2].duty = duty_cnt;
        break;
    case PWM3_BASE:
        LOG_TRACE("drv8874_set_duty: setting PWM3 duty to %" PRIu32 " of %" PRIu32 "(%" PRIu32 "\%)", duty_cnt, (uint32_t)DRV8874_PWM_PERIOD, duty_cnt/DRV8874_PWM_PERIOD);
        drv8874_irq_data[DRV8874_PWM3].duty = duty_cnt;
        break;
    case PWM4_BASE:
        LOG_TRACE("drv8874_set_duty: setting PWM4 duty to %" PRIu32 " of %" PRIu32 "(%" PRIu32 "\%)", duty_cnt, (uint32_t)DRV8874_PWM_PERIOD, duty_cnt/DRV8874_PWM_PERIOD);
        drv8874_irq_data[DRV8874_PWM4].duty = duty_cnt;
        break;
    default:
        LOG_ERROR("drv8874_set_duty: invalid pwm device base address 0x%p", config->pwm_base);
        TDX_ASSERT(TDX_ERROR_INVALID);
    }
}

void drv8874_irq_handler_test(void) {
    static       bool     pwm_increase_duty = true;
    static       uint32_t pwm_duty          = 10000U;
    static const uint32_t pwm_duty_min      = 10000U;
    static const uint32_t pwm_duty_max      = 50000U;
    static const uint32_t pwm_duty_step     = 1000U;

    LOG_TRACE("in PWM1 IRQ handler");

    /* Gets interrupt kPWM_FIFOEmptyFlag */
    if (PWM_GetStatusFlags(PWM1) & kPWM_FIFOEmptyFlag){
        if (pwm_increase_duty) {
            /* Increase duty cycle until it reach limited value. */
            if(pwm_duty <= pwm_duty_max - pwm_duty_step) {
                pwm_duty += pwm_duty_step;
                LOG_TRACE("PWM1: increasing duty to %u", pwm_duty);
            } else {
                LOG_TRACE("PWM1: pwm_duty reached max");
                pwm_duty = pwm_duty_max;
                pwm_increase_duty = false;
            }
        } else {
            /* Decrease duty cycle until it reach limited value. */
            if(pwm_duty >= pwm_duty_min + pwm_duty_step) {
                pwm_duty -= pwm_duty_step;
                LOG_TRACE("PWM1: decreasing duty to %u", pwm_duty);
            } else {
                LOG_TRACE("PWM1: pwm_duty reached min");
                pwm_duty = pwm_duty_min;
                pwm_increase_duty = true;
            }
        }
        /* Write duty cycle to PWM sample register. */
        PWM_SetSampleValue(PWM1, pwm_duty);
        /* Clear kPWM_FIFOEmptyFlag */
        PWM_clearStatusFlags(PWM1, kPWM_FIFOEmptyFlag);
    }
    SDK_ISR_EXIT_BARRIER;
}
