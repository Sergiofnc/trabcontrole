#ifndef DRV8874_H
#define DRV8874_H

#include <stdint.h>
#include <stdbool.h>

#include "MIMX8ML8_cm7.h"

#include "fsl_gpio.h"
#include "fsl_pwm.h"
#include "fsl_common.h"

#include "libs/tdxerr.h"

// GPIO pin configuration structure
typedef struct {
    GPIO_Type *ph_base;    // GPIO port for the PH pin (for PH/EN mode)
    uint32_t   ph_pin;     // PH pin number (for PH/EN mode)
    GPIO_Type *nsleep_base;
    uint32_t   nsleep_pin;
    PWM_Type  *pwm_base;
    bool       reverse;
} drv8874_config_t;

void drv8874_init(drv8874_config_t *data, const uint32_t freq);
void drv8874_set_duty(drv8874_config_t *config, float percent);

#endif // DRV8874_H
