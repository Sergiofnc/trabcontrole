#include "encoder_int.h"

#include "libs/tdxlog.h"
#include "libs/tdxerr.h"

// Stores encoder data to use in interrupts.
tdxenc_state_t encoders[TDXENC_ENCODER_MAX];

// IO state bits, used to compose the address in the transition matrix
// Current GPIO A state
#define TDXENC_CURR_GPIO_A (1 << 0)
// Current GPIO B state
#define TDXENC_CURR_GPIO_B (1 << 1)
// Previous GPIO A state
#define TDXENC_PREV_GPIO_A (1 << 2)
// Previous GPIO B state
#define TDXENC_PREV_GPIO_B (1 << 3)

// Transition matrix, populated on constructor.
int8_t tdxenc_transition_matrix[16];
int8_t tdxenc_transition_matrix_reverse[16];

// Returns the first free slot in the array, setting `slot_in_use` to true.
static uint8_t tdxenc_alloc_enc(tdxenc_state_t *enc_array, const size_t enc_array_slots) {
    size_t enc_index = 0;

    // Scan the array
    while(enc_index < enc_array_slots) {
        // Find first free slot
        if(enc_array[enc_index].slot_in_use == false) {
            // Set the entry to "in use"
            enc_array[enc_index].slot_in_use = true;
            // And return the index
            return enc_index;
        }
        enc_index++;
    }

    // Throwing so we won't reach the return statement
    TDX_ASSERT(TDX_ERROR_UNAVAILABLE);
    return -1;
}

// Clears all data in this entry's slot, making it available for future use.
static void tdxenc_clear_entry(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    // Disable the interrypts as they are not necessary anymore
    DisableIRQ(enc->gpio_a.irq_n);
    DisableIRQ(enc->gpio_b.irq_n);

    // Define the gpio reset state
    const tdxenc_gpio_data_t gpio_reset = {
        .base  = NULL,
        .pin   = 0,
        .irq_n = NotAvail_IRQn,
    };

    // Define the the encoder reset state
    const tdxenc_state_t enc_reset = {
        .reverse             = false,
        .io_state            = 0,
        .gpio_a              = gpio_reset,
        .gpio_b              = gpio_reset,
        .ringbuf_index       = 0,
        .ringbuf_sum         = 0,
        .counts_since_start     = 0,
        .slot_in_use         = false,
    };

    // Setting reset state
    *enc = enc_reset;
    // Clearing ringbuf
    memset(enc->ringbuf, 0, TDXENC_RINGBUF_SLOTS*sizeof(enc->ringbuf[0]));
}

// Reads the gpios and constructs the state representation.
static int tdxenc_get_gpio_state(tdxenc_state_t *enc) {
    const uint32_t gpio_a_value = GPIO_PinRead(enc->gpio_a.base, enc->gpio_a.pin);
    const uint32_t gpio_b_value = GPIO_PinRead(enc->gpio_b.base, enc->gpio_b.pin);

    // Ensure no transitions happened between gpio_a and gpio_b reads
    if(
        gpio_a_value == GPIO_PinRead(enc->gpio_a.base, enc->gpio_a.pin) &&
        gpio_b_value == GPIO_PinRead(enc->gpio_b.base, enc->gpio_b.pin)
    ) {
        // No transitions, returning state from combination of masks
        const int gpio_a_mask = gpio_a_value ? TDXENC_CURR_GPIO_A : 0x00;
        const int gpio_b_mask = gpio_b_value ? TDXENC_CURR_GPIO_B : 0x00;
        return gpio_a_mask | gpio_b_mask;
    } else {
        // Tried to read during an encoder transition, trying again...
        return tdxenc_get_gpio_state(enc);
    }
}

// Updates IO state for the given encoder.
// Only populates the PREV slots in `enc->io_state`, while cleaning the CURR slots.
static void tdxenc_update_io_state(tdxenc_state_t *enc, const int new_state) {
    // Clear io_state
    enc->io_state = 0;

    // Then check for the new state bits to enable the old state bits
    enc->io_state |= new_state & TDXENC_CURR_GPIO_A ? TDXENC_PREV_GPIO_A : 0x00;
    enc->io_state |= new_state & TDXENC_CURR_GPIO_B ? TDXENC_PREV_GPIO_B : 0x00;
}

// Returns the encoder instance associated to the provided index
tdxenc_state_t *tdxenc_get(const uint8_t enc_index) {
    return &(encoders[enc_index]);
}

// Creates a new encoder instance.
uint8_t tdxenc_new_enc(
          GPIO_Type *gpio_a_base,
    const uint32_t   gpio_a_pin,
    const IRQn_Type  gpio_a_irqn,
          GPIO_Type *gpio_b_base,
    const uint32_t   gpio_b_pin,
    const IRQn_Type  gpio_b_irqn,
    const bool       reverse,
    const uint64_t   window_duration
) {
    const gpio_pin_config_t gpio_config = {
        .direction     = kGPIO_DigitalInput,
        .outputLogic   = 0,
        .interruptMode = kGPIO_IntRisingOrFallingEdge,
    };

    // Init GPIOs as input with rising edge and falling edge interrupts
    GPIO_PinInit(gpio_a_base, gpio_a_pin, &gpio_config);
    GPIO_PinInit(gpio_b_base, gpio_b_pin, &gpio_config);

    // Creating a new encoder instance
    const uint8_t enc_index = tdxenc_alloc_enc(encoders, TDXENC_ENCODER_MAX);
    // Then accessing the allocated encoder
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    // Add gpio_a data
    enc->gpio_a.base  = gpio_a_base;
    enc->gpio_a.pin   = gpio_a_pin;
    enc->gpio_a.irq_n = gpio_a_irqn;

    // Add gpio_b data
    enc->gpio_b.base  = gpio_b_base;
    enc->gpio_b.pin   = gpio_b_pin;
    enc->gpio_b.irq_n = gpio_b_irqn;

    // Set encoder direction
    enc->reverse      = reverse;

    // Set sampling window
    enc->sampling_window_time = window_duration;

    // Read initial state to compare on first interrupt
    tdxenc_update_io_state(enc, tdxenc_get_gpio_state(enc));

    // Filling the samples buffer with empty samples, as we need the starting time
    // We do this before enabling interrupts to avoid counts/time where time is 0
    uint8_t sample_index = 0;
    const tdxenc_ringbuf_t initial_ringbuf_entry = {
        .counts    = 0,
        .time_init = tdxtick_get_tick(),
    };

    while(sample_index < TDXENC_RINGBUF_SLOTS) {
        enc->ringbuf[sample_index] = initial_ringbuf_entry;
        sample_index++;
    }

    // Enable interrupts
    EnableIRQ(gpio_a_irqn);
    GPIO_PortEnableInterrupts(gpio_a_base, 1 << gpio_a_pin);
    EnableIRQ(gpio_b_irqn);
    GPIO_PortEnableInterrupts(gpio_b_base, 1 << gpio_b_pin);

    return enc_index;
}

// Returns the encoder system to the state it was just after initialization.
void tdxenc_deinit() {
    size_t enc_index = 0;

    // Clear every entry as they may contain garbage in slot_in_use
    // Which would break the allocator implementation
    while(enc_index < TDXENC_ENCODER_MAX) {
        tdxenc_clear_entry(enc_index);
        enc_index++;
    }
}

// Frees encoder slot.
void tdxenc_free(const uint8_t enc_index) {
    tdxenc_clear_entry(enc_index);
}

static void tdxenc_update_ringbuf_head(tdxenc_state_t *enc) {
    // Low update freq latency reducer
    const uint64_t time_passed_since_last_update = tdxtick_get_tick() - enc->ringbuf[enc->ringbuf_index].time_init;
    const uint64_t required_head_moves = time_passed_since_last_update / enc->sampling_window_time;

    if(required_head_moves > TDXENC_RINGBUF_SLOTS) {
        // Passed so much time that we would overwrite the entire ringbuf and more
        // Here we are going to skip only the "useless" moves, as we still need to
        // go once through all the entries to update the ringbuf sum
        enc->ringbuf[enc->ringbuf_index].time_init += (required_head_moves - TDXENC_RINGBUF_SLOTS)*enc->sampling_window_time;
    }

    // Normal operation with high update freq
    while(tdxtick_get_tick() >= enc->ringbuf[enc->ringbuf_index].time_init + enc->sampling_window_time) {
        // Save this sample's initial time
        const uint64_t prev_time = enc->ringbuf[enc->ringbuf_index].time_init;

        // Move the ringbuf writing head
        enc->ringbuf_index++;

        // Wraps if reached the end of the buffer
        if(enc->ringbuf_index >= TDXENC_RINGBUF_SLOTS) {
            enc->ringbuf_index = 0;
        }

        // Remove old sample from accumulator
        enc->ringbuf_sum -= enc->ringbuf[enc->ringbuf_index].counts;

        // Move the initial time one window slot
        enc->ringbuf[enc->ringbuf_index].time_init = prev_time + enc->sampling_window_time;
        // And clear the counts for the next use
        enc->ringbuf[enc->ringbuf_index].counts = 0;
    }
}

// Finds the oldest sample in enc ringbuf and returns its time in ticks
static uint64_t tdxenc_find_oldest_sample(const tdxenc_state_t *enc) {
    if(enc->ringbuf_index + 1 < TDXENC_RINGBUF_SLOTS) {
        // The next slot is the oldest
        return enc->ringbuf[enc->ringbuf_index + 1].time_init;
    } else {
        // We are on the last slot, so slot 0 is the oldest
        return enc->ringbuf[0].time_init;
    }
}

// Finds the newest sample in enc ringbuf and returns its time in ticks
static uint64_t tdxenc_find_newest_sample(const tdxenc_state_t *enc) {
    return enc->ringbuf[enc->ringbuf_index].time_init;
}

// Returns the encoder counts per second as float.
float tdxenc_get_cps(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    // Disable IRQ to prevent read while writing on enc variables
    DisableIRQ(enc->gpio_a.irq_n);
    DisableIRQ(enc->gpio_b.irq_n);

    // The ringbuf_sum may be outdated
    tdxenc_update_ringbuf_head(enc);

    const float    total_count   = (float)enc->ringbuf_sum;
    const uint64_t oldest_sample = tdxenc_find_oldest_sample(enc);
    const uint64_t now           = tdxtick_get_tick();

    // Re-enable interrupts before math as it may take some precious cpu cycles
    EnableIRQ(enc->gpio_a.irq_n);
    EnableIRQ(enc->gpio_b.irq_n);

    return total_count/tdxtick_time_diff(oldest_sample, now);
}

// Returns the total counts since the encoder initialization or a reference-frame update
int32_t tdxenc_get_counts(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    // Disable IRQ to prevent read while writing on counts_since_start
    DisableIRQ(enc->gpio_a.irq_n);
    DisableIRQ(enc->gpio_b.irq_n);

    const int32_t total_counts = enc->counts_since_start;

    EnableIRQ(enc->gpio_a.irq_n);
    EnableIRQ(enc->gpio_b.irq_n);

    return total_counts;
}

// Sets the total distance travelled by the robot to 0
// Returns the value it held before clearing
int32_t tdxenc_update_reference_frame(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    // Disable IRQ to prevent read while writing on pulses_since_start
    DisableIRQ(enc->gpio_a.irq_n);
    DisableIRQ(enc->gpio_b.irq_n);

    // Save the value before setting to 0
    const int32_t total_counts = enc->counts_since_start;
    // Then set to 0
    enc->counts_since_start = 0;

    EnableIRQ(enc->gpio_a.irq_n);
    EnableIRQ(enc->gpio_b.irq_n);

    return total_counts;
}

static int8_t tdxenc_get_transition(const int transit, bool reversed) {
    return reversed ? tdxenc_transition_matrix_reverse[transit] : tdxenc_transition_matrix[transit];
}

// This should be called only inside the interrupt
static void tdxenc_update_sample(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    if(enc->slot_in_use) {
        // Get updated IO state as it is required to find the signal transitions
        const int new_state = tdxenc_get_gpio_state(enc);

        // Contains both new state and previous state
        const int full_state = new_state | enc->io_state;

        // Check for transitions from old state to new state
        const int8_t trans = tdxenc_get_transition(full_state, enc->reverse);

        if(trans != 0) {
            const uint64_t now = tdxtick_get_tick();
            const uint64_t entry_start = tdxenc_find_newest_sample(enc);
            if (now >= entry_start + enc->sampling_window_time) {
                tdxenc_update_ringbuf_head(enc);
            }

            // Add the new sample to the accumulator
            enc->ringbuf_sum += trans;

            // Update the counter due to transitions
            enc->ringbuf[enc->ringbuf_index].counts += trans;

            // Add to the total pulses since start, used to measure distance travelled
            enc->counts_since_start += trans;

            // Set new_state as the current state, as it is required for the next iteration
            tdxenc_update_io_state(enc, new_state);
        }
    }
}

// Clear this pin interrupt or we are going to stay in the interrupt forever
static void tdxenc_clear_isr(const uint8_t enc_index) {
    tdxenc_state_t *enc = tdxenc_get(enc_index);

    if(enc->slot_in_use) {
        // This GPIO function uses a bit mask instead of the pin number
        GPIO_PortClearInterruptFlags(enc->gpio_a.base, 1 << enc->gpio_a.pin);
        GPIO_PortClearInterruptFlags(enc->gpio_b.base, 1 << enc->gpio_b.pin);
    }
}

// Call this from the interrupt handler
void tdxenc_irq_handler() {
    uint8_t enc_index = 0;
    while(enc_index < TDXENC_ENCODER_MAX) {
        tdxenc_update_sample(enc_index);
        tdxenc_clear_isr(enc_index);
        enc_index++;
    }
}

__attribute__((constructor))
static void tdxenc_boot() {
    tdxenc_deinit();

    // Initializing transition matrix
    // Idle states
    tdxenc_transition_matrix[              0x00 |               0x00 |               0x00 |               0x00] =  0; // A low,     B low
    tdxenc_transition_matrix[              0x00 |               0x00 | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] =  0; // A high,    B low
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B |               0x00 |               0x00] =  0; // A low,     B high
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] =  0; // A high,    B high

    // Positive transitions
    tdxenc_transition_matrix[              0x00 |               0x00 |               0x00 | TDXENC_CURR_GPIO_A] = +1; // A rising,  B low
    tdxenc_transition_matrix[              0x00 | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] = +1; // A high,    B rising
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A |               0x00] = +1; // A falling, B high
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B |               0x00 |               0x00 |               0x00] = +1; // A low,     B falling

    // Negative transitions
    tdxenc_transition_matrix[              0x00 | TDXENC_CURR_GPIO_B |               0x00 |               0x00] = -1; // B rising,  A low
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B |               0x00 | TDXENC_CURR_GPIO_A] = -1; // B high,    A rising
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B |               0x00 | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] = -1; // B falling, A high
    tdxenc_transition_matrix[              0x00 |               0x00 | TDXENC_PREV_GPIO_A |               0x00] = -1; // B low,     A falling

    // Invalid transitions
    tdxenc_transition_matrix[              0x00 | TDXENC_CURR_GPIO_B |               0x00 | TDXENC_CURR_GPIO_A] =  0; // A and B rising simultaneously
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B |               0x00 |               0x00 | TDXENC_CURR_GPIO_A] =  0; // A rising and B falling
    tdxenc_transition_matrix[TDXENC_PREV_GPIO_B |               0x00 | TDXENC_PREV_GPIO_A |               0x00] =  0; // A and B falling simultaneously
    tdxenc_transition_matrix[              0x00 | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A |               0x00] =  0; // A falling and B rising

    // Initializing transition matrix for reversed inputs
    // Idle states
    tdxenc_transition_matrix_reverse[              0x00 |               0x00 |               0x00 |               0x00] =  0; // A low,     B low
    tdxenc_transition_matrix_reverse[              0x00 |               0x00 | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] =  0; // A high,    B low
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B |               0x00 |               0x00] =  0; // A low,     B high
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] =  0; // A high,    B high

    // "Positive" transitions
    tdxenc_transition_matrix_reverse[              0x00 |               0x00 |               0x00 | TDXENC_CURR_GPIO_A] = -1; // A rising,  B low
    tdxenc_transition_matrix_reverse[              0x00 | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] = -1; // A high,    B rising
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A |               0x00] = -1; // A falling, B high
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B |               0x00 |               0x00 |               0x00] = -1; // A low,     B falling

    // "Negative" transitions
    tdxenc_transition_matrix_reverse[              0x00 | TDXENC_CURR_GPIO_B |               0x00 |               0x00] = +1; // B rising,  A low
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B | TDXENC_CURR_GPIO_B |               0x00 | TDXENC_CURR_GPIO_A] = +1; // B high,    A rising
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B |               0x00 | TDXENC_PREV_GPIO_A | TDXENC_CURR_GPIO_A] = +1; // B falling, A high
    tdxenc_transition_matrix_reverse[              0x00 |               0x00 | TDXENC_PREV_GPIO_A |               0x00] = +1; // B low,     A falling

    // Invalid transitions
    tdxenc_transition_matrix_reverse[              0x00 | TDXENC_CURR_GPIO_B |               0x00 | TDXENC_CURR_GPIO_A] =  0; // A and B rising simultaneously
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B |               0x00 |               0x00 | TDXENC_CURR_GPIO_A] =  0; // A rising and B falling
    tdxenc_transition_matrix_reverse[TDXENC_PREV_GPIO_B |               0x00 | TDXENC_PREV_GPIO_A |               0x00] =  0; // A and B falling simultaneously
    tdxenc_transition_matrix_reverse[              0x00 | TDXENC_CURR_GPIO_B | TDXENC_PREV_GPIO_A |               0x00] =  0; // A falling and B rising
}
